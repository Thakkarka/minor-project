# 🏥 AI Healthcare Clinical Decision Support System

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![React 18](https://img.shields.io/badge/react-18-blue.svg)](https://reactjs.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.104-green.svg)](https://fastapi.tiangolo.com/)

An advanced AI-powered Clinical Decision Support System (CDSS) that assists healthcare professionals in symptom analysis, differential diagnosis, risk assessment, and medical literature retrieval.

## ✨ Features

- 🩺 **Symptom Analysis** - Natural language processing of patient symptoms
- 🎯 **Differential Diagnosis** - AI-powered diagnosis generation with confidence scores
- 📊 **Risk Assessment** - Comprehensive risk scoring with mortality prediction
- 📚 **Literature Search** - Medical literature retrieval with RAG
- 💬 **AI Chat Assistant** - Interactive medical Q&A
- 📈 **Patient History** - Track analyses over time
- 🎨 **Modern UI** - Beautiful, responsive interface with dark mode

## 🚀 Quick Start

### Prerequisites
- Python 3.11+
- Node.js 18+
- Git

### Installation

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/ai-healthcare-cdss.git
cd ai-healthcare-cdss

# Backend setup
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt

# Frontend setup
cd ../frontend
npm install

# Database setup
cd ../database
python setup_db.py

# Start the application
# Terminal 1 (Backend)
cd backend
uvicorn app.main:app --reload --port 8000

# Terminal 2 (Frontend)
cd frontend
npm start