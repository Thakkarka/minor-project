from fastapi import APIRouter, HTTPException
from typing import Dict, Any
from loguru import logger
from pydantic import BaseModel

from app.services.gemini_service import GeminiService

router = APIRouter()
gemini_service = GeminiService()

class ChatMessage(BaseModel):
    message: str
    patient_context: Dict[str, Any] = None
    session_id: str = None

class ChatResponse(BaseModel):
    response: str
    session_id: str
    suggestions: list = []

@router.post("/message", response_model=ChatResponse)
async def chat_message(message: ChatMessage):
    """
    Send a message to the AI assistant
    """
    try:
        logger.info(f"Processing chat message")
        
        # Get response from Gemini
        response = await gemini_service.chat(
            user_message=message.message,
            patient_context=message.patient_context,
            session_id=message.session_id
        )
        
        return ChatResponse(
            response=response["message"],
            session_id=response["session_id"],
            suggestions=response.get("suggestions", [])
        )
        
    except Exception as e:
        logger.error(f"Error in chat: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/clear/{session_id}")
async def clear_session(session_id: str):
    """
    Clear chat session
    """
    try:
        gemini_service.clear_session(session_id)
        return {"status": "success", "message": "Session cleared"}
    except Exception as e:
        logger.error(f"Error clearing session: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))