from fastapi import APIRouter, HTTPException
from typing import List, Dict, Any
from loguru import logger

from app.schemas.diagnosis_schema import DiagnosisRequest, DiagnosisResponse

router = APIRouter()

@router.post("/differential", response_model=DiagnosisResponse)
async def get_differential_diagnosis(request: DiagnosisRequest):
    """
    Generate differential diagnosis based on symptoms and patient data
    """
    try:
        logger.info(f"Generating differential diagnosis for symptoms: {request.symptoms}")
        
        # Generate mock diagnosis based on symptoms
        symptoms_lower = ' '.join(request.symptoms).lower()
        
        # Determine diagnosis based on symptoms
        if 'headache' in symptoms_lower:
            primary = "Tension Headache"
            differentials = [
                {"condition": "Tension Headache", "probability": 0.70, "reasoning": "Most common type, often stress-related"},
                {"condition": "Migraine", "probability": 0.20, "reasoning": "Could be migraine if throbbing with nausea"},
                {"condition": "Sinusitis", "probability": 0.10, "reasoning": "If associated with facial pain"}
            ]
            confidence = 0.75
            tests = ["Physical examination", "Blood pressure check", "Neurological assessment"]
            treatments = ["Rest in quiet environment", "Hydration", "OTC pain relievers if appropriate"]
            reasoning = "Based on reported headache symptoms, tension-type headache is most likely."
            
        elif 'chest' in symptoms_lower or 'breath' in symptoms_lower:
            primary = "Anxiety/Panic Attack"
            differentials = [
                {"condition": "Anxiety/Panic Attack", "probability": 0.60, "reasoning": "Common with stress"},
                {"condition": "GERD", "probability": 0.25, "reasoning": "Can mimic cardiac pain"},
                {"condition": "Musculoskeletal", "probability": 0.15, "reasoning": "Costochondritis possible"}
            ]
            confidence = 0.65
            tests = ["ECG", "Chest X-ray", "Blood work including troponin"]
            treatments = ["Deep breathing exercises", "Stress management", "Follow up with PCP"]
            reasoning = "Symptoms are concerning but likely non-cardiac given presentation."
            
        elif 'fever' in symptoms_lower:
            primary = "Viral Upper Respiratory Infection"
            differentials = [
                {"condition": "Viral URI", "probability": 0.70, "reasoning": "Most common cause"},
                {"condition": "Influenza", "probability": 0.20, "reasoning": "If fever >101°F with body aches"},
                {"condition": "Bacterial Infection", "probability": 0.10, "reasoning": "If symptoms persist >7 days"}
            ]
            confidence = 0.70
            tests = ["CBC", "Rapid flu test", "COVID test if indicated"]
            treatments = ["Rest", "Hydration", "Acetaminophen for fever", "Monitor symptoms"]
            reasoning = "Fever with systemic symptoms suggests viral illness."
            
        else:
            primary = "Unspecified Condition"
            differentials = [
                {"condition": "Viral Syndrome", "probability": 0.50, "reasoning": "Common presentation"},
                {"condition": "Stress-related symptoms", "probability": 0.30, "reasoning": "Consider if no organic cause"},
                {"condition": "Other causes", "probability": 0.20, "reasoning": "Further evaluation needed"}
            ]
            confidence = 0.60
            tests = ["Complete blood count", "Basic metabolic panel", "Physical examination"]
            treatments = ["Symptomatic treatment", "Follow up if symptoms persist", "Rest and hydration"]
            reasoning = "Symptoms are non-specific. Further history and examination needed."
        
        return DiagnosisResponse(
            primary_diagnosis=primary,
            differential_diagnoses=differentials,
            confidence_score=confidence,
            recommended_tests=tests,
            treatment_suggestions=treatments,
            clinical_reasoning=reasoning,
            evidence_level="Moderate - Based on clinical presentation"
        )
        
    except Exception as e:
        logger.error(f"Error generating diagnosis: {str(e)}")
        # Return default diagnosis
        return DiagnosisResponse(
            primary_diagnosis="Viral Syndrome",
            differential_diagnoses=[
                {"condition": "Viral Syndrome", "probability": 0.70, "reasoning": "Common presentation"},
                {"condition": "Bacterial Infection", "probability": 0.20, "reasoning": "If fever persists"},
                {"condition": "Allergic Reaction", "probability": 0.10, "reasoning": "If seasonal"}
            ],
            confidence_score=0.65,
            recommended_tests=["CBC", "Physical exam"],
            treatment_suggestions=["Rest", "Hydration", "Monitor symptoms"],
            clinical_reasoning="Based on reported symptoms, viral syndrome is most likely.",
            evidence_level="Limited - Further evaluation may be needed"
        )