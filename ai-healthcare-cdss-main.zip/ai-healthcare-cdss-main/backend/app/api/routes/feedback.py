from fastapi import APIRouter, HTTPException
from loguru import logger
from pydantic import BaseModel
from typing import Optional

from app.schemas.feedback_schema import FeedbackRequest
from app.database.crud import save_feedback

router = APIRouter()

@router.post("/submit")
async def submit_feedback(feedback: FeedbackRequest):
    """
    Submit feedback for diagnosis or symptom analysis
    """
    try:
        logger.info(f"Submitting feedback for: {feedback.diagnosis_id}")
        
        # Save feedback to database
        saved_feedback = save_feedback(feedback.dict())
        
        return {
            "status": "success",
            "message": "Feedback submitted successfully",
            "feedback_id": saved_feedback["id"]
        }
        
    except Exception as e:
        logger.error(f"Error submitting feedback: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/diagnosis/{diagnosis_id}")
async def get_diagnosis_feedback(diagnosis_id: str):
    """
    Get feedback for a specific diagnosis
    """
    try:
        from app.database.crud import get_feedback_for_diagnosis
        feedback = get_feedback_for_diagnosis(diagnosis_id)
        return {"diagnosis_id": diagnosis_id, "feedback": feedback}
    except Exception as e:
        logger.error(f"Error fetching feedback: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))