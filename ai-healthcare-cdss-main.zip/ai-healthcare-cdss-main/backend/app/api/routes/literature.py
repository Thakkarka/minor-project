from fastapi import APIRouter
from loguru import logger

router = APIRouter()

# Medical knowledge base
MEDICAL_ARTICLES = {
    "hypertension": {
        "title": "Hypertension Management Guidelines 2024",
        "summary": "Hypertension affects 1 in 3 adults. First-line treatments include ACE inhibitors, ARBs, and calcium channel blockers. Target BP <130/80 mmHg.",
        "detailed_info": "Lifestyle modifications: DASH diet, sodium restriction, regular exercise. Medications: ACE inhibitors, ARBs, CCBs, diuretics.",
        "source": "Clinical Guidelines",
        "year": 2024
    },
    "diabetes": {
        "title": "Type 2 Diabetes Management",
        "summary": "Type 2 diabetes requires glycemic control, cardiovascular risk management, and lifestyle changes. Target A1c <7%.",
        "detailed_info": "First-line: Metformin. Additional: SGLT2 inhibitors, GLP-1 agonists. Monitor HbA1c every 3-6 months.",
        "source": "ADA Guidelines",
        "year": 2024
    },
    "pneumonia": {
        "title": "Community-Acquired Pneumonia Treatment",
        "summary": "CAP requires prompt antibiotic therapy. CURB-65 score guides admission decisions.",
        "detailed_info": "Outpatient: amoxicillin or doxycycline. Inpatient: beta-lactam + macrolide.",
        "source": "IDSA Guidelines",
        "year": 2023
    },
    "migraine": {
        "title": "Migraine Treatment Guidelines",
        "summary": "Acute treatment: triptans, NSAIDs. Preventive: beta-blockers, anticonvulsants.",
        "detailed_info": "Acute: sumatriptan, ibuprofen. Preventive: propranolol, topiramate, amitriptyline.",
        "source": "AHS Guidelines",
        "year": 2024
    },
    "asthma": {
        "title": "Asthma Management Guidelines",
        "summary": "Stepwise approach: ICS first-line, add LABA if needed, biologics for severe cases.",
        "detailed_info": "Step 1: SABA as needed. Step 2: Low-dose ICS. Step 3: ICS/LABA.",
        "source": "GINA Guidelines",
        "year": 2024
    },
    "copd": {
        "title": "COPD Management Guidelines",
        "summary": "Bronchodilators first-line, add ICS for exacerbations, pulmonary rehabilitation.",
        "detailed_info": "LABA/LAMA for maintenance. ICS for frequent exacerbations. Smoking cessation essential.",
        "source": "GOLD Guidelines",
        "year": 2024
    }
}

@router.post("/search")
async def search_literature(request: dict):
    """Search medical literature"""
    query = request.get("query", "").lower()
    logger.info(f"Searching for: {query}")
    
    results = []
    
    # Search in medical articles
    for key, article in MEDICAL_ARTICLES.items():
        if key in query or query in key:
            results.append({
                "title": article["title"],
                "summary": article["summary"],
                "detailed_info": article.get("detailed_info", ""),
                "source": article["source"],
                "year": article["year"],
                "relevance_score": 0.9
            })
    
    # If no exact match, show some results
    if not results:
        results = [
            {
                "title": "Hypertension Guidelines",
                "summary": "Management of high blood pressure",
                "source": "Clinical Guidelines",
                "year": 2024,
                "relevance_score": 0.7
            },
            {
                "title": "Diabetes Care Standards",
                "summary": "Comprehensive diabetes management",
                "source": "ADA",
                "year": 2024,
                "relevance_score": 0.7
            },
            {
                "title": "Pneumonia Treatment",
                "summary": "Community-acquired pneumonia guidelines",
                "source": "IDSA",
                "year": 2023,
                "relevance_score": 0.7
            }
        ]
    
    return {
        "query": query,
        "results": results,
        "total_found": len(results)
    }