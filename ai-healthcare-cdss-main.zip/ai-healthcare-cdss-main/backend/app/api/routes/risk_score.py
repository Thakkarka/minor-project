from fastapi import APIRouter, HTTPException
from typing import Dict, Any
from loguru import logger

from app.schemas.risk_schema import RiskRequest, RiskResponse
from app.services.risk_calculator import RiskCalculator
from app.services.cache_service import CacheService

router = APIRouter()
risk_calculator = RiskCalculator()
cache_service = CacheService()

@router.post("/calculate", response_model=RiskResponse)
async def calculate_risk_score(request: RiskRequest):
    """
    Calculate risk score based on patient data and diagnosis
    """
    try:
        logger.info(f"Calculating risk score for patient")
        
        # Calculate risk
        risk_assessment = await risk_calculator.calculate(
            age=request.age,
            symptoms=request.symptoms,
            vital_signs=request.vital_signs,
            medical_history=request.medical_history,
            diagnosis=request.diagnosis
        )
        
        return risk_assessment
        
    except Exception as e:
        logger.error(f"Error calculating risk: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/interpret/{score}")
async def interpret_risk_score(score: float):
    """
    Get interpretation for a risk score
    """
    try:
        interpretation = risk_calculator.interpret_score(score)
        return {"score": score, "interpretation": interpretation}
    except Exception as e:
        logger.error(f"Error interpreting score: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))