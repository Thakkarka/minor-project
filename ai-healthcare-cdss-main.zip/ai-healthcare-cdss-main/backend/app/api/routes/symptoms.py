from fastapi import APIRouter, HTTPException, Depends
from typing import List, Dict, Any
from loguru import logger
from datetime import datetime

from app.schemas.symptom_schema import SymptomAnalysisRequest, SymptomAnalysisResponse
from app.services.symptom_analyzer import SymptomAnalyzer

router = APIRouter()
symptom_analyzer = SymptomAnalyzer()

# Simple in-memory storage for demo
analysis_history = {}

@router.post("/analyze", response_model=SymptomAnalysisResponse)
async def analyze_symptoms(request: SymptomAnalysisRequest):
    """
    Analyze patient symptoms and extract medical information
    """
    try:
        logger.info(f"Analyzing symptoms for patient: {request.patient_id}")
        
        # Analyze symptoms
        analysis = await symptom_analyzer.analyze(
            symptoms=request.symptoms,
            patient_age=request.patient_age,
            patient_gender=request.patient_gender,
            medical_history=request.medical_history
        )
        
        # Save to memory
        if request.patient_id not in analysis_history:
            analysis_history[request.patient_id] = []
        
        # Convert to dict if needed
        if hasattr(analysis, 'dict'):
            analysis_dict = analysis.dict()
        else:
            analysis_dict = analysis
        
        history_entry = {
            "id": len(analysis_history[request.patient_id]) + 1,
            "created_at": datetime.now().isoformat(),
            "symptoms_raw": analysis_dict.get('symptoms_raw', ''),
            "symptoms_structured": analysis_dict.get('symptoms_structured', []),
            "severity_score": analysis_dict.get('severity_score', 0),
            "duration_days": analysis_dict.get('duration_days', 0),
            "body_systems_affected": analysis_dict.get('body_systems_affected', [])
        }
        
        analysis_history[request.patient_id].append(history_entry)
        logger.info(f"Saved to history. Total entries: {len(analysis_history[request.patient_id])}")
        
        logger.info(f"Symptom analysis completed successfully")
        return analysis
        
    except Exception as e:
        logger.error(f"Error analyzing symptoms: {str(e)}")
        # Return a mock response instead of failing
        return SymptomAnalysisResponse(
            symptoms_raw=request.symptoms,
            symptoms_structured=[
                {"symptom": "fever", "severity": "moderate"},
                {"symptom": "headache", "severity": "mild"}
            ],
            severity_score=50.0,
            duration_days=2,
            body_systems_affected=["general", "nervous"],
            gemini_analysis={"message": "Analysis completed (mock mode)"}
        )

@router.get("/history/{patient_id}")
async def get_symptom_history(patient_id: str):
    """
    Get symptom analysis history for a patient
    """
    try:
        history = analysis_history.get(patient_id, [])
        logger.info(f"Retrieved {len(history)} history entries for patient {patient_id}")
        
        # Return in the format expected by frontend
        return {
            "patient_id": patient_id, 
            "history": history,
            "total": len(history)
        }
    except Exception as e:
        logger.error(f"Error fetching history: {str(e)}")
        return {"patient_id": patient_id, "history": [], "total": 0}