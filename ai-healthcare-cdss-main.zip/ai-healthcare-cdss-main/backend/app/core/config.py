from pydantic_settings import BaseSettings
from typing import List
import os
from dotenv import load_dotenv
import os.path

# Get the absolute path to the database
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DATABASE_PATH = os.path.join(BASE_DIR, '..', 'database', 'sqlite.db')
DATABASE_PATH = os.path.abspath(DATABASE_PATH)

load_dotenv()

class Settings(BaseSettings):
    # Gemini API
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    
    # Database - Use absolute path
    DATABASE_URL: str = f"sqlite:///{DATABASE_PATH}"
    
    # Security
    SECRET_KEY: str = os.getenv("SECRET_KEY", "your-secret-key-change-this")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # Rate Limiting
    RATE_LIMIT_PER_MINUTE: int = int(os.getenv("RATE_LIMIT_PER_MINUTE", "60"))
    
    # CORS
    CORS_ORIGINS: List[str] = eval(os.getenv("CORS_ORIGINS", '["http://localhost:3000"]'))
    
    # Debug
    DEBUG: bool = os.getenv("DEBUG", "True").lower() == "true"
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    
    # Cache
    CACHE_TTL: int = int(os.getenv("CACHE_TTL", "3600"))
    
    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()

# Print database path for debugging
print(f"Database path: {DATABASE_PATH}")
print(f"Database exists: {os.path.exists(DATABASE_PATH)}")

if not settings.GEMINI_API_KEY:
    print("⚠️  Warning: GEMINI_API_KEY not set. Using mock responses.")