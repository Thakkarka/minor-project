import sqlite3
import json
from datetime import datetime
from typing import List, Dict, Any
import os

# Direct path to database
DB_PATH = r'C:\Users\HP\ai-healthcare-cdss\database\sqlite.db'

def get_connection():
    """Get database connection"""
    return sqlite3.connect(DB_PATH)

# Symptom Analysis CRUD
def save_symptom_analysis(patient_id: str, analysis: Dict) -> Dict:
    """Save symptom analysis to database"""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        symptoms_structured = analysis.get('symptoms_structured', [])
        if isinstance(symptoms_structured, str):
            symptoms_structured = json.loads(symptoms_structured)
        
        body_systems = analysis.get('body_systems_affected', [])
        if isinstance(body_systems, str):
            body_systems = json.loads(body_systems)
        
        cursor.execute("""
            INSERT INTO symptom_analyses (
                patient_id, symptoms_raw, symptoms_structured, 
                severity_score, duration_days, body_systems_affected, 
                created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            patient_id,
            analysis.get('symptoms_raw', ''),
            json.dumps(symptoms_structured),
            analysis.get('severity_score', 0),
            analysis.get('duration_days', 0),
            json.dumps(body_systems),
            datetime.now().isoformat(),
            datetime.now().isoformat()
        ))
        conn.commit()
        return {"id": cursor.lastrowid, "status": "saved", "patient_id": patient_id}
    except Exception as e:
        print(f"Error saving symptom analysis: {e}")
        conn.rollback()
        raise
    finally:
        conn.close()

def get_patient_symptom_history(patient_id: str, limit: int = 10) -> List[Dict]:
    """Get symptom analysis history for a patient"""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT * FROM symptom_analyses 
            WHERE patient_id = ? 
            ORDER BY created_at DESC 
            LIMIT ?
        """, (patient_id, limit))
        rows = cursor.fetchall()
        
        # Get column names
        columns = [description[0] for description in cursor.description]
        results = []
        
        for row in rows:
            result = dict(zip(columns, row))
            # Parse JSON fields
            if result.get('symptoms_structured'):
                try:
                    result['symptoms_structured'] = json.loads(result['symptoms_structured'])
                except:
                    result['symptoms_structured'] = []
            if result.get('body_systems_affected'):
                try:
                    result['body_systems_affected'] = json.loads(result['body_systems_affected'])
                except:
                    result['body_systems_affected'] = []
            results.append(result)
        return results
    except Exception as e:
        print(f"Error fetching history: {e}")
        return []
    finally:
        conn.close()

# Patient CRUD
def create_patient(patient_data: Dict) -> Dict:
    """Create a new patient record"""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO patients (patient_id, age, gender, medical_history, medications, allergies)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            patient_data.get('patient_id'),
            patient_data.get('age'),
            patient_data.get('gender'),
            json.dumps(patient_data.get('medical_history', [])),
            json.dumps(patient_data.get('medications', [])),
            json.dumps(patient_data.get('allergies', []))
        ))
        conn.commit()
        return {"id": cursor.lastrowid, "patient_id": patient_data.get('patient_id')}
    except Exception as e:
        print(f"Error creating patient: {e}")
        conn.rollback()
        raise
    finally:
        conn.close()

def get_patient(patient_id: str) -> Dict:
    """Get patient by ID"""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM patients WHERE patient_id = ?", (patient_id,))
        row = cursor.fetchone()
        if row:
            columns = [description[0] for description in cursor.description]
            result = dict(zip(columns, row))
            # Parse JSON fields
            if result.get('medical_history'):
                try:
                    result['medical_history'] = json.loads(result['medical_history'])
                except:
                    result['medical_history'] = []
            if result.get('medications'):
                try:
                    result['medications'] = json.loads(result['medications'])
                except:
                    result['medications'] = []
            if result.get('allergies'):
                try:
                    result['allergies'] = json.loads(result['allergies'])
                except:
                    result['allergies'] = []
            return result
        return None
    finally:
        conn.close()

# Diagnosis CRUD
def save_diagnosis(patient_id: str, diagnosis_data: Dict) -> Dict:
    """Save diagnosis to database"""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO diagnoses (
                patient_id, primary_diagnosis, differential_diagnoses, 
                confidence_score, recommended_tests, treatment_suggestions,
                clinical_reasoning, evidence_level
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            patient_id,
            diagnosis_data.get('primary_diagnosis', ''),
            json.dumps(diagnosis_data.get('differential_diagnoses', [])),
            diagnosis_data.get('confidence_score', 0),
            json.dumps(diagnosis_data.get('recommended_tests', [])),
            json.dumps(diagnosis_data.get('treatment_suggestions', [])),
            diagnosis_data.get('clinical_reasoning', ''),
            diagnosis_data.get('evidence_level', '')
        ))
        conn.commit()
        return {"id": cursor.lastrowid, "patient_id": patient_id}
    except Exception as e:
        print(f"Error saving diagnosis: {e}")
        conn.rollback()
        raise
    finally:
        conn.close()

# Risk Assessment CRUD
def save_risk_assessment(patient_id: str, risk_data: Dict) -> Dict:
    """Save risk assessment to database"""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO risk_assessments (
                patient_id, risk_score, risk_level, risk_factors, 
                mortality_risk_30d, recommended_actions
            ) VALUES (?, ?, ?, ?, ?, ?)
        """, (
            patient_id,
            risk_data.get('risk_score', 0),
            risk_data.get('risk_level', ''),
            json.dumps(risk_data.get('risk_factors', [])),
            risk_data.get('mortality_risk_30d', 0),
            json.dumps(risk_data.get('recommended_actions', []))
        ))
        conn.commit()
        return {"id": cursor.lastrowid, "patient_id": patient_id}
    except Exception as e:
        print(f"Error saving risk assessment: {e}")
        conn.rollback()
        raise
    finally:
        conn.close()

# Feedback CRUD
def save_feedback(feedback_data: Dict) -> Dict:
    """Save user feedback"""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO feedback (diagnosis_id, patient_id, accuracy_rating, helpfulness_rating, comments, suggested_diagnosis)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            feedback_data.get('diagnosis_id', ''),
            feedback_data.get('patient_id', ''),
            feedback_data.get('accuracy_rating', 0),
            feedback_data.get('helpfulness_rating', 0),
            feedback_data.get('comments', ''),
            feedback_data.get('suggested_diagnosis', '')
        ))
        conn.commit()
        return {"id": cursor.lastrowid, "status": "saved"}
    except Exception as e:
        print(f"Error saving feedback: {e}")
        conn.rollback()
        raise
    finally:
        conn.close()

def get_feedback_for_diagnosis(diagnosis_id: str) -> List[Dict]:
    """Get all feedback for a diagnosis"""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM feedback WHERE diagnosis_id = ?", (diagnosis_id,))
        rows = cursor.fetchall()
        columns = [description[0] for description in cursor.description]
        results = [dict(zip(columns, row)) for row in rows]
        return results
    finally:
        conn.close()