import sqlite3
import os

# Direct path to database
DB_PATH = r'C:\Users\HP\ai-healthcare-cdss\database\sqlite.db'

def get_db_connection():
    """Get direct database connection"""
    return sqlite3.connect(DB_PATH)

def test_connection():
    """Test database connection"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        print(f"Connected to database. Tables: {[t[0] for t in tables]}")
        conn.close()
        return True
    except Exception as e:
        print(f"Database error: {e}")
        return False

if __name__ == "__main__":
    test_connection()