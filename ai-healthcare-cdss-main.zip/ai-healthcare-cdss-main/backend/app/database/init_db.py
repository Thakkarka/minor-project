from sqlalchemy import create_engine
from .session import engine, Base
from app.models.symptom import SymptomAnalysis
from app.models.patient import Patient
from app.models.diagnosis import Diagnosis
from app.models.risk_assessment import RiskAssessment
from app.models.literature import LiteratureCache
from app.models.feedback import Feedback
from loguru import logger
import os

def init_database():
    """Initialize database - create all tables"""
    try:
        logger.info("Creating database tables...")
        Base.metadata.create_all(bind=engine)
        logger.info("Database tables created successfully")
        
        # Verify tables were created
        from sqlalchemy import inspect
        inspector = inspect(engine)
        tables = inspector.get_table_names()
        logger.info(f"Tables created: {tables}")
        
    except Exception as e:
        logger.error(f"Error creating database tables: {str(e)}")
        raise

def drop_database():
    """Drop all tables (use with caution)"""
    try:
        logger.warning("Dropping all database tables...")
        Base.metadata.drop_all(bind=engine)
        logger.info("Database tables dropped")
    except Exception as e:
        logger.error(f"Error dropping tables: {str(e)}")
        raise