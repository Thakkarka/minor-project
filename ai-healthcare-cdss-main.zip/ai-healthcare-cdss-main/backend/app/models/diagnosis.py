from sqlalchemy import Column, Integer, String, Float, DateTime, JSON, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class Diagnosis(Base):
    __tablename__ = "diagnoses"
    
    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(String, index=True)
    symptom_analysis_id = Column(Integer, ForeignKey("symptom_analyses.id"))
    primary_diagnosis = Column(String)
    differential_diagnoses = Column(JSON)  # List of dicts with condition and probability
    confidence_score = Column(Float)
    recommended_tests = Column(JSON, default=list)
    treatment_suggestions = Column(JSON, default=list)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            "id": self.id,
            "patient_id": self.patient_id,
            "primary_diagnosis": self.primary_diagnosis,
            "differential_diagnoses": self.differential_diagnoses,
            "confidence_score": self.confidence_score,
            "recommended_tests": self.recommended_tests,
            "treatment_suggestions": self.treatment_suggestions,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }