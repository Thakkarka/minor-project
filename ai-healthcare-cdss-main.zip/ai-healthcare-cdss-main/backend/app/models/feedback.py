from sqlalchemy import Column, Integer, String, Float, DateTime, JSON, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class Feedback(Base):
    __tablename__ = "feedback"
    
    id = Column(Integer, primary_key=True, index=True)
    diagnosis_id = Column(String, index=True)
    patient_id = Column(String, index=True)
    accuracy_rating = Column(Integer)  # 1-5 stars
    helpfulness_rating = Column(Integer)  # 1-5
    comments = Column(String)
    suggested_diagnosis = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            "id": self.id,
            "diagnosis_id": self.diagnosis_id,
            "patient_id": self.patient_id,
            "accuracy_rating": self.accuracy_rating,
            "helpfulness_rating": self.helpfulness_rating,
            "comments": self.comments,
            "suggested_diagnosis": self.suggested_diagnosis,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }