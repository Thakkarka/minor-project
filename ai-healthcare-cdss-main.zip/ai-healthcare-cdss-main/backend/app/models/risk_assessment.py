from sqlalchemy import Column, Integer, String, Float, DateTime, JSON, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class RiskAssessment(Base):
    __tablename__ = "risk_assessments"
    
    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(String, index=True)
    diagnosis_id = Column(Integer, ForeignKey("diagnoses.id"))
    risk_score = Column(Float)
    risk_level = Column(String)  # Low, Moderate, High, Critical
    risk_factors = Column(JSON)  # List of factors contributing to risk
    mortality_risk_30d = Column(Float)
    recommended_actions = Column(JSON, default=list)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            "id": self.id,
            "patient_id": self.patient_id,
            "risk_score": self.risk_score,
            "risk_level": self.risk_level,
            "risk_factors": self.risk_factors,
            "mortality_risk_30d": self.mortality_risk_30d,
            "recommended_actions": self.recommended_actions,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }