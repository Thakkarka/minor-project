from sqlalchemy import Column, Integer, String, Float, DateTime, JSON, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class SymptomAnalysis(Base):
    __tablename__ = "symptom_analyses"
    
    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(String, index=True)
    symptoms_raw = Column(JSON)
    symptoms_structured = Column(JSON)
    severity_score = Column(Float)
    duration_days = Column(Integer)
    body_systems_affected = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            "id": self.id,
            "patient_id": self.patient_id,
            "symptoms_raw": self.symptoms_raw,
            "symptoms_structured": self.symptoms_structured,
            "severity_score": self.severity_score,
            "duration_days": self.duration_days,
            "body_systems_affected": self.body_systems_affected,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }