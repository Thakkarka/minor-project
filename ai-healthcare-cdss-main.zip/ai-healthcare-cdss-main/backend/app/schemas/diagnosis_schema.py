from pydantic import BaseModel, Field
from typing import List, Optional, Dict
from datetime import datetime

class DiagnosisRequest(BaseModel):
    patient_id: str
    symptoms: List[str]
    vital_signs: Optional[Dict] = {}
    risk_factors: Optional[List[str]] = []
    patient_age: Optional[int] = None

class DiagnosisResponse(BaseModel):
    primary_diagnosis: str
    differential_diagnoses: List[Dict]
    confidence_score: float = Field(..., ge=0, le=1)
    recommended_tests: List[str]
    treatment_suggestions: List[str]
    clinical_reasoning: Optional[str] = ""
    evidence_level: Optional[str] = ""
    created_at: datetime = Field(default_factory=datetime.now)

class LiteratureSearchRequest(BaseModel):
    query: str = Field(..., min_length=3)
    top_k: Optional[int] = 5