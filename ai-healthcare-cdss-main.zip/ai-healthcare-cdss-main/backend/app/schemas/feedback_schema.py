from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class FeedbackRequest(BaseModel):
    diagnosis_id: str
    patient_id: str
    accuracy_rating: int = Field(..., ge=1, le=5)
    helpfulness_rating: int = Field(..., ge=1, le=5)
    comments: Optional[str] = ""
    suggested_diagnosis: Optional[str] = None

class FeedbackResponse(BaseModel):
    id: int
    diagnosis_id: str
    patient_id: str
    accuracy_rating: int
    helpfulness_rating: int
    comments: str
    suggested_diagnosis: Optional[str]
    created_at: datetime