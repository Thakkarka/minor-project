from pydantic import BaseModel, Field
from typing import List, Dict, Optional
from datetime import datetime

class RiskRequest(BaseModel):
    age: int = Field(..., ge=0, le=150)
    symptoms: List[str]
    vital_signs: Dict
    medical_history: List[str]
    diagnosis: Optional[str] = None

class RiskResponse(BaseModel):
    risk_score: float = Field(..., ge=0, le=100)
    risk_level: str
    risk_factors: List[str]
    mortality_risk_30d: float = Field(..., ge=0, le=100)
    recommended_actions: List[str]
    created_at: datetime = Field(default_factory=datetime.now)