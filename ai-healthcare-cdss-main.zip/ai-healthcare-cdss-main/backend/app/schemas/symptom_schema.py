from pydantic import BaseModel, Field
from typing import List, Optional, Dict
from datetime import datetime

class SymptomAnalysisRequest(BaseModel):
    patient_id: str
    symptoms: str = Field(..., min_length=1, max_length=5000)
    patient_age: Optional[int] = Field(None, ge=0, le=150)
    patient_gender: Optional[str] = Field(None, pattern="^(male|female|other)$")
    medical_history: Optional[List[str]] = []

class SymptomAnalysisResponse(BaseModel):
    symptoms_raw: str
    symptoms_structured: List[Dict]
    severity_score: float
    duration_days: int
    body_systems_affected: List[str]
    gemini_analysis: Optional[Dict] = {}
    created_at: datetime = Field(default_factory=datetime.now)