from typing import Any, Optional
from cachetools import TTLCache
from datetime import datetime
from loguru import logger

class CacheService:
    def __init__(self, max_size: int = 1000, ttl: int = 3600):
        """Initialize cache service with TTL cache"""
        self.cache = TTLCache(maxsize=max_size, ttl=ttl)
        self.ttl = ttl
        
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache"""
        try:
            value = self.cache.get(key)
            if value:
                logger.debug(f"Cache hit for key: {key}")
            return value
        except Exception as e:
            logger.error(f"Cache get error: {str(e)}")
            return None
    
    def set(self, key: str, value: Any, ttl: int = None) -> bool:
        """Set value in cache with optional custom TTL"""
        try:
            if ttl and ttl != self.ttl:
                # For custom TTL, we would need a different cache implementation
                # For now, use default TTL
                pass
            
            self.cache[key] = value
            logger.debug(f"Cached value for key: {key}")
            return True
        except Exception as e:
            logger.error(f"Cache set error: {str(e)}")
            return False
    
    def delete(self, key: str) -> bool:
        """Delete value from cache"""
        try:
            if key in self.cache:
                del self.cache[key]
                logger.debug(f"Deleted cache key: {key}")
            return True
        except Exception as e:
            logger.error(f"Cache delete error: {str(e)}")
            return False
    
    def clear(self) -> bool:
        """Clear all cache"""
        try:
            self.cache.clear()
            logger.info("Cache cleared")
            return True
        except Exception as e:
            logger.error(f"Cache clear error: {str(e)}")
            return False
    
    def get_stats(self) -> dict:
        """Get cache statistics"""
        return {
            "size": len(self.cache),
            "max_size": self.cache.maxsize,
            "ttl": self.ttl
        }