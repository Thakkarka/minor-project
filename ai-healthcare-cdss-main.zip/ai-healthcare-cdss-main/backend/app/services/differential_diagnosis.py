from typing import List, Dict, Any
from loguru import logger
from app.services.gemini_service import GeminiService

class DifferentialDiagnosisService:
    def __init__(self):
        self.gemini_service = GeminiService()
        
    async def generate_differential(self, symptoms: List[str], vital_signs: Dict,
                                   risk_factors: List[str], patient_age: int) -> Dict:
        """Generate differential diagnosis"""
        try:
            # Prepare patient data
            patient_data = {
                "age": patient_age,
                "vital_signs": vital_signs,
                "risk_factors": risk_factors
            }
            
            # Convert symptoms list to structured format
            symptoms_dict = {"symptoms": symptoms}
            
            # Get diagnosis from Gemini
            diagnosis = await self.gemini_service.generate_differential_diagnosis(
                symptoms_dict, patient_data
            )
            
            # Add clinical reasoning
            diagnosis["clinical_reasoning"] = self._generate_reasoning(
                diagnosis, symptoms, patient_data
            )
            
            # Add evidence level
            diagnosis["evidence_level"] = self._assess_evidence_level(diagnosis)
            
            return diagnosis
            
        except Exception as e:
            logger.error(f"Differential diagnosis error: {str(e)}")
            return self._get_default_diagnosis(symptoms)
    
    def _generate_reasoning(self, diagnosis: Dict, symptoms: List[str], 
                           patient_data: Dict) -> str:
        """Generate clinical reasoning for diagnosis"""
        primary = diagnosis.get('primary_diagnosis', 'Unknown')
        confidence = diagnosis.get('confidence_score', 0)
        
        reasoning = f"The primary diagnosis is {primary} with {confidence*100:.0f}% confidence. "
        
        # Add symptom-based reasoning
        if symptoms:
            reasoning += f"Key presenting symptoms include {', '.join(symptoms[:3])}. "
        
        # Add patient factor reasoning
        if patient_data.get('age', 0) > 65:
            reasoning += "Age is a significant factor in this presentation. "
        
        return reasoning
    
    def _assess_evidence_level(self, diagnosis: Dict) -> str:
        """Assess level of evidence for diagnosis"""
        confidence = diagnosis.get('confidence_score', 0)
        
        if confidence > 0.8:
            return "High - Strong evidence supporting diagnosis"
        elif confidence > 0.6:
            return "Moderate - Reasonable evidence available"
        elif confidence > 0.4:
            return "Low - Limited evidence, consider further testing"
        else:
            return "Very Low - Insufficient evidence, broad differential needed"
    
    def _get_default_diagnosis(self, symptoms: List[str]) -> Dict:
        """Return default diagnosis on error"""
        return {
            "primary_diagnosis": "Unspecified condition",
            "differential_diagnoses": [
                {"condition": "Viral syndrome", "probability": 0.40, 
                 "reasoning": "Common presentation"},
                {"condition": "Bacterial infection", "probability": 0.30,
                 "reasoning": "Consider if fever present"},
                {"condition": "Other causes", "probability": 0.30,
                 "reasoning": "Further evaluation needed"}
            ],
            "confidence_score": 0.50,
            "recommended_tests": ["Complete blood count", "Basic metabolic panel"],
            "treatment_suggestions": ["Supportive care", "Monitor symptoms"],
            "clinical_reasoning": "Based on reported symptoms, further clinical correlation needed.",
            "evidence_level": "Low - Limited evidence, consider further testing"
        }