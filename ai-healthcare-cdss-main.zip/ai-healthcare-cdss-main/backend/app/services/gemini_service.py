import google.generativeai as genai
from typing import Dict, Any, List, Optional
from loguru import logger
import json
import re
from datetime import datetime

from app.core.config import settings

class GeminiService:
    def __init__(self):
        """Initialize Gemini API service"""
        self.model = None
        self.use_mock = True
        
        try:
            # Check if API key is provided
            if not settings.GEMINI_API_KEY or settings.GEMINI_API_KEY == "":
                logger.warning("No Gemini API key provided. Using mock responses.")
                self.use_mock = True
                return
            
            genai.configure(api_key=settings.GEMINI_API_KEY)
            
            # Try different model names (updated working models)
            model_names = [
                'gemini-1.0-pro',
                'gemini-pro',
                'models/gemini-1.0-pro'
            ]
            
            for model_name in model_names:
                try:
                    self.model = genai.GenerativeModel(model_name)
                    # Test the model with a simple prompt
                    test_response = self.model.generate_content("Hello")
                    if test_response and test_response.text:
                        logger.info(f"Successfully loaded model: {model_name}")
                        self.use_mock = False
                        break
                except Exception as e:
                    logger.warning(f"Could not load {model_name}: {e}")
                    continue
            
            if self.model is None:
                logger.warning("No Gemini model available. Using mock responses.")
                self.use_mock = True
                
        except Exception as e:
            logger.error(f"Failed to initialize Gemini: {e}")
            self.use_mock = True
        
        self.chat_sessions = {}
    
    def _clean_json_response(self, text: str) -> str:
        """Clean JSON response from markdown and extra text"""
        # Remove markdown code blocks
        text = re.sub(r'```json\s*', '', text)
        text = re.sub(r'```\s*', '', text)
        # Find JSON object
        match = re.search(r'\{.*\}', text, re.DOTALL)
        if match:
            return match.group(0)
        return text
    
    async def analyze_symptoms(self, symptoms_text: str, patient_context: Dict = None) -> Dict:
        """Analyze symptoms using Gemini or mock"""
        if self.use_mock:
            logger.info("Using mock symptom analysis")
            return self._get_mock_symptom_analysis(symptoms_text)
            
        try:
            prompt = f"""You are a medical AI assistant. Analyze the following patient symptoms and return ONLY valid JSON:

Symptoms: {symptoms_text}

Return JSON format:
{{"extracted_symptoms": [{{"symptom": "symptom name", "severity": "mild/moderate/severe"}}], "affected_systems": ["system1"], "duration_classification": "acute/subacute/chronic", "urgency_level": "low/medium/high/emergency"}}"""
            
            response = self.model.generate_content(prompt)
            cleaned = self._clean_json_response(response.text)
            result = json.loads(cleaned)
            return result
            
        except Exception as e:
            logger.error(f"Gemini API error: {str(e)}")
            return self._get_mock_symptom_analysis(symptoms_text)
    
    async def generate_differential_diagnosis(self, symptoms: Dict, patient_data: Dict) -> Dict:
        """Generate differential diagnosis"""
        if self.use_mock:
            logger.info("Using mock diagnosis")
            return self._get_mock_diagnosis(symptoms)
            
        try:
            prompt = f"""Based on symptoms: {json.dumps(symptoms)} and patient: {json.dumps(patient_data)}, return ONLY valid JSON:
{{"primary_diagnosis": "name", "differential_diagnoses": [{{"condition": "name", "probability": 0.70, "reasoning": "why"}}], "confidence_score": 0.75, "recommended_tests": ["test1"], "treatment_suggestions": ["suggestion1"]}}"""
            
            response = self.model.generate_content(prompt)
            cleaned = self._clean_json_response(response.text)
            result = json.loads(cleaned)
            return result
            
        except Exception as e:
            logger.error(f"Gemini API error: {str(e)}")
            return self._get_mock_diagnosis(symptoms)
    
    async def chat(self, user_message: str, patient_context: Dict = None, session_id: str = None) -> Dict:
        """Handle chat conversation"""
        if self.use_mock:
            logger.info("Using mock chat response")
            return self._get_mock_chat_response(user_message, session_id)
            
        try:
            if not session_id or session_id not in self.chat_sessions:
                session_id = f"session_{datetime.now().timestamp()}"
                self.chat_sessions[session_id] = self.model.start_chat(history=[])
            
            response = self.chat_sessions[session_id].send_message(user_message)
            
            return {
                "message": response.text,
                "session_id": session_id,
                "suggestions": ["What are the common treatments?", "When should I see a doctor?", "Any home remedies?"]
            }
            
        except Exception as e:
            logger.error(f"Chat error: {str(e)}")
            return self._get_mock_chat_response(user_message, session_id)
    
    def clear_session(self, session_id: str):
        if session_id in self.chat_sessions:
            del self.chat_sessions[session_id]
    
    def _get_mock_symptom_analysis(self, symptoms_text=""):
        return {
            "extracted_symptoms": [
                {"symptom": symptoms_text if symptoms_text else "fever", "severity": "moderate"}
            ],
            "affected_systems": ["general"],
            "duration_classification": "acute",
            "urgency_level": "low"
        }
    
    def _get_mock_diagnosis(self, symptoms=None):
        symptom_str = str(symptoms).lower() if symptoms else ""
        
        if "headache" in symptom_str:
            return {
                "primary_diagnosis": "Tension Headache",
                "differential_diagnoses": [
                    {"condition": "Tension Headache", "probability": 0.70, "reasoning": "Most common type"},
                    {"condition": "Migraine", "probability": 0.20, "reasoning": "Possible with aura"},
                    {"condition": "Sinusitis", "probability": 0.10, "reasoning": "If facial pain present"}
                ],
                "confidence_score": 0.75,
                "recommended_tests": ["Physical exam", "Blood pressure check"],
                "treatment_suggestions": ["Rest", "Hydration", "OTC pain relievers"]
            }
        elif "chest" in symptom_str or "breath" in symptom_str:
            return {
                "primary_diagnosis": "Anxiety/Panic Attack",
                "differential_diagnoses": [
                    {"condition": "Anxiety", "probability": 0.60, "reasoning": "Common presentation"},
                    {"condition": "GERD", "probability": 0.25, "reasoning": "Can mimic chest pain"},
                    {"condition": "Musculoskeletal", "probability": 0.15, "reasoning": "Costochondritis possible"}
                ],
                "confidence_score": 0.65,
                "recommended_tests": ["ECG", "Chest X-ray", "Blood work"],
                "treatment_suggestions": ["Deep breathing", "Stress management", "Follow up with PCP"]
            }
        else:
            return {
                "primary_diagnosis": "Viral Syndrome",
                "differential_diagnoses": [
                    {"condition": "Viral Infection", "probability": 0.70, "reasoning": "Common presentation"},
                    {"condition": "Bacterial Infection", "probability": 0.20, "reasoning": "If fever persists"},
                    {"condition": "Allergic Reaction", "probability": 0.10, "reasoning": "If seasonal"}
                ],
                "confidence_score": 0.70,
                "recommended_tests": ["CBC", "Physical exam"],
                "treatment_suggestions": ["Rest", "Hydration", "Monitor symptoms"]
            }
    
    def _get_mock_chat_response(self, user_message: str, session_id: str = None) -> Dict:
        if not session_id:
            session_id = f"mock_session_{datetime.now().timestamp()}"
        
        user_lower = user_message.lower()
        
        if "diabetes" in user_lower:
            response = "**Diabetes Information:**\n\nSymptoms include increased thirst, frequent urination, fatigue, and blurred vision. Type 2 diabetes is managed with diet, exercise, and medications like metformin. Always consult your doctor for proper diagnosis and treatment."
        elif "hypertension" in user_lower or "blood pressure" in user_lower:
            response = "**High Blood Pressure (Hypertension):**\n\nNormal BP is <120/80. Lifestyle modifications include reducing sodium, regular exercise, maintaining healthy weight, and limiting alcohol. Medications include ACE inhibitors, ARBs, and calcium channel blockers."
        elif "fever" in user_lower:
            response = "**Fever Management:**\n\nLow-grade fever (37.5-38°C) usually doesn't need treatment. For higher fevers, rest, hydration, and OTC medications like acetaminophen or ibuprofen can help. Seek care if fever >40°C or lasts >3 days."
        elif "headache" in user_lower:
            response = "**Headache Relief:**\n\nCommon causes include tension, dehydration, or lack of sleep. Try rest, hydration, and OTC pain relievers. Seek emergency care for sudden severe headache or headache with neurological symptoms."
        else:
            response = f"Thank you for your question. As an AI medical assistant, I can provide general health information. For specific medical advice, please consult a healthcare provider. You can ask me about diabetes, hypertension, fever, headaches, and common medical conditions."
        
        return {
            "message": response,
            "session_id": session_id,
            "suggestions": ["What are diabetes symptoms?", "How to lower blood pressure?", "When to see a doctor for fever?", "Headache home remedies?"]
        }