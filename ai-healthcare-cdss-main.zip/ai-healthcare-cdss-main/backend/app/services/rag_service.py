from typing import List, Dict, Any
from loguru import logger
import json
import re

class RAGService:
    def __init__(self):
        """Initialize RAG service with medical knowledge base"""
        self.knowledge_base = self._get_mock_knowledge_base()
        
    async def retrieve_relevant_articles(self, query: str, top_k: int = 5) -> List[Dict]:
        """Retrieve relevant medical articles based on query"""
        try:
            logger.info(f"Searching literature for: {query}")
            
            relevant_articles = []
            query_lower = query.lower()
            
            # Search in knowledge base
            for condition, data in self.knowledge_base.items():
                # Check if query matches keywords or condition name
                relevance = 0
                all_keywords = [condition.lower()] + data.get('keywords', [])
                
                for keyword in all_keywords:
                    if keyword in query_lower:
                        relevance += 10
                    elif query_lower in keyword:
                        relevance += 5
                
                # Check for partial matches
                for word in query_lower.split():
                    for keyword in all_keywords:
                        if word in keyword or keyword in word:
                            relevance += 3
                
                if relevance > 0:
                    relevant_articles.append({
                        "title": data.get('title', condition),
                        "condition": condition,
                        "summary": data.get('summary', ''),
                        "detailed_info": data.get('detailed_info', ''),
                        "relevance_score": min(relevance / 20, 1.0),
                        "source": "Medical Knowledge Base",
                        "year": data.get('year', 2024),
                        "references": data.get('references', [])
                    })
            
            # Sort by relevance and return top_k
            relevant_articles.sort(key=lambda x: x['relevance_score'], reverse=True)
            results = relevant_articles[:top_k]
            
            logger.info(f"Found {len(results)} relevant articles")
            return results
            
        except Exception as e:
            logger.error(f"Retrieval error: {str(e)}")
            return self._get_default_results(query)
    
    def get_article_details(self, article_id: str) -> Dict:
        """Get detailed information for a specific article"""
        for condition, data in self.knowledge_base.items():
            if condition.lower() == article_id.lower():
                return {
                    "id": article_id,
                    "title": data.get('title', condition),
                    "full_text": data.get('detailed_info', ''),
                    "references": data.get('references', []),
                    "last_updated": str(data.get('year', 2024))
                }
        return None
    
    def _get_mock_knowledge_base(self) -> Dict:
        """Return medical knowledge base"""
        return {
            "Hypertension": {
                "keywords": ["hypertension", "high blood pressure", "blood pressure", "bp", "hypertensive"],
                "title": "Management of Hypertension: Clinical Guidelines 2024",
                "summary": "Hypertension affects 1 in 3 adults. First-line treatments include ACE inhibitors, ARBs, and calcium channel blockers. Target BP <130/80 mmHg.",
                "detailed_info": """**Hypertension Management Guidelines**

**First-line medications:**
- ACE inhibitors (lisinopril, enalapril)
- ARBs (losartan, valsartan) 
- Calcium channel blockers (amlodipine)
- Thiazide diuretics

**Lifestyle modifications:**
- DASH diet (rich in fruits, vegetables, low-fat dairy)
- Sodium restriction <1500mg/day
- Regular exercise (150 min/week moderate intensity)
- Weight loss if overweight (5-10% reduction)
- Limit alcohol (<2 drinks/day men, <1 women)
- Smoking cessation

**Monitoring:**
- Home BP monitoring
- Annual labs (creatinine, electrolytes, lipids)
- Follow-up every 3-6 months until controlled""",
                "year": 2024,
                "references": ["ACC/AHA 2017 Guidelines", "ESC/ESH 2018 Guidelines"]
            },
            "Diabetes": {
                "keywords": ["diabetes", "diabetic", "blood sugar", "glucose", "type 2 diabetes", "t2dm"],
                "title": "Type 2 Diabetes Mellitus: Comprehensive Care",
                "summary": "Type 2 diabetes requires multifactorial approach including glycemic control, cardiovascular risk management, and lifestyle changes. Target A1c <7%.",
                "detailed_info": """**Diabetes Management Guidelines**

**First-line therapy:**
- Metformin (unless contraindicated)
- Lifestyle modification (diet, exercise, weight loss)

**Additional agents (if needed):**
- SGLT2 inhibitors (empagliflozin) - cardiovascular/renal benefits
- GLP-1 agonists (semaglutide) - weight loss, CV benefits
- DPP-4 inhibitors (sitagliptin) - well tolerated
- Sulfonylureas (glipizide) - effective, risk of hypoglycemia
- Insulin - for severe hyperglycemia or A1c >10%

**Monitoring:**
- HbA1c every 3-6 months (target <7%)
- Annual eye exam, foot exam, urine albumin
- Blood pressure control (<130/80)
- Lipid management (statin therapy)

**Lifestyle:**
- Medical nutrition therapy
- Physical activity (150 min/week)
- Weight loss (5-10% if overweight)""",
                "year": 2024,
                "references": ["ADA Standards of Care 2024", "AACE Guidelines 2023"]
            },
            "Pneumonia": {
                "keywords": ["pneumonia", "lung infection", "chest infection", "cap", "community acquired pneumonia"],
                "title": "Community-Acquired Pneumonia: Diagnosis and Treatment",
                "summary": "CAP requires prompt antibiotic therapy based on severity. CURB-65 score guides admission decisions.",
                "detailed_info": """**Pneumonia Management**

**Outpatient treatment:**
- Amoxicillin (first-line)
- Doxycycline (alternative)
- Macrolide (if low resistance)

**Inpatient treatment:**
- Beta-lactam + macrolide
- Respiratory fluoroquinolone monotherapy

**Severity assessment (CURB-65):**
- Confusion
- Uremia (BUN >19 mg/dL)
- Respiratory rate ≥30
- Low BP (SBP <90 or DBP ≤60)
- Age ≥65 years

**When to admit:**
- CURB-65 score ≥2
- Hypoxia (O2 sat <90%)
- Unable to tolerate oral intake
- Comorbidities (COPD, CHF, diabetes)

**Follow-up:**
- Chest X-ray at 6 weeks (if age >50 or smokers)
- Pneumococcal and influenza vaccines""",
                "year": 2023,
                "references": ["IDSA/ATS Guidelines 2019", "BTS Guidelines 2023"]
            },
            "Migraine": {
                "keywords": ["migraine", "headache", "aura", "chronic headache", "migraines"],
                "title": "Acute and Preventive Migraine Treatment",
                "summary": "Migraine treatment includes acute abortive therapy and preventive medications for frequent attacks.",
                "detailed_info": """**Migraine Management**

**Acute treatment (at onset):**
- NSAIDs (ibuprofen, naproxen)
- Triptans (sumatriptan, rizatriptan)
- Antiemetics (metoclopramide for nausea)
- Gepants (ubrogepant, rimegepant) - newer options

**Preventive treatment (≥4 attacks/month):**
- Beta-blockers (propranolol, metoprolol)
- Anticonvulsants (topiramate, valproate)
- Antidepressants (amitriptyline, venlafaxine)
- CGRP antagonists (erenumab, galcanezumab)

**Lifestyle modifications:**
- Regular sleep schedule
- Stress management
- Identify and avoid triggers
- Regular meals, hydration
- Exercise (aerobic)

**When to seek emergency care:**
- Sudden severe headache (thunderclap)
- Neurological symptoms (weakness, speech changes)
- Headache with fever or stiff neck""",
                "year": 2024,
                "references": ["AHS Guidelines 2021", "EFNS Guidelines"]
            },
            "COPD": {
                "keywords": ["copd", "chronic obstructive pulmonary disease", "emphysema", "chronic bronchitis", "breathing difficulty"],
                "title": "COPD: Diagnosis and Management",
                "summary": "COPD management includes bronchodilators, inhaled corticosteroids, pulmonary rehabilitation, and smoking cessation.",
                "detailed_info": """**COPD Management**

**Pharmacologic therapy:**
- Short-acting bronchodilators (SABA, SAMA) for rescue
- Long-acting bronchodilators (LABA, LAMA) for maintenance
- Inhaled corticosteroids (ICS) for exacerbations
- Triple therapy (ICS/LABA/LAMA) for severe disease

**Non-pharmacologic:**
- Smoking cessation (most important!)
- Pulmonary rehabilitation
- Vaccinations (influenza, pneumococcal, COVID-19)
- Oxygen therapy if hypoxemic

**Exacerbation management:**
- Increase bronchodilator frequency
- Oral corticosteroids (40mg prednisone x5 days)
- Antibiotics if signs of infection
- Hospitalization if severe

**Monitoring:**
- Spirometry annually
- Exacerbation frequency
- Oxygen saturation
- Dyspnea scales (mMRC, CAT)""",
                "year": 2024,
                "references": ["GOLD Guidelines 2024", "ATS/ERS Guidelines"]
            },
            "Asthma": {
                "keywords": ["asthma", "wheezing", "breathing difficulty", "airway", "bronchial"],
                "title": "Asthma Management Guidelines",
                "summary": "Asthma treatment follows stepwise approach based on symptom control. Inhaled corticosteroids are first-line.",
                "detailed_info": """**Asthma Management**

**Stepwise approach:**
- Step 1: SABA as needed
- Step 2: Low-dose ICS + as-needed SABA
- Step 3: Low-dose ICS/LABA + as-needed SABA
- Step 4: Medium-dose ICS/LABA + as-needed SABA
- Step 5: High-dose ICS/LABA + add-on therapy
- Step 6: High-dose ICS/LABA + oral corticosteroids

**Add-on therapies:**
- Tiotropium (LAMA)
- Anti-IgE (omalizumab) if allergic
- Anti-IL5 (mepolizumab) for eosinophilic
- Macrolides (azithromycin)

**Monitoring:**
- Symptom control (ACT score)
- Spirometry (FEV1/FVC ratio)
- Exacerbation frequency
- Inhaler technique

**Action plan:**
- Green zone: well-controlled, daily controller
- Yellow zone: symptoms present, increase reliever
- Red zone: severe symptoms, seek emergency care""",
                "year": 2024,
                "references": ["GINA Guidelines 2024", "NAEPP Guidelines"]
            }
        }
    
    def _get_default_results(self, query: str) -> List[Dict]:
        """Return default results when search fails"""
        return [
            {
                "title": "Medical Literature Search",
                "summary": f"Search results for '{query}' will appear here. Try searching for: hypertension, diabetes, pneumonia, migraine, COPD, or asthma.",
                "relevance_score": 0.5,
                "source": "Information",
                "year": 2024
            }
        ]