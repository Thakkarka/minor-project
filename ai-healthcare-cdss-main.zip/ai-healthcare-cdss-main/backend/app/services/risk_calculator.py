from typing import Dict, Any, List
from loguru import logger
import math

class RiskCalculator:
    def __init__(self):
        """Initialize risk calculator with risk models"""
        self.risk_weights = {
            'age': self._calculate_age_risk,
            'vitals': self._calculate_vitals_risk,
            'symptoms': self._calculate_symptoms_risk,
            'history': self._calculate_history_risk
        }
    
    async def calculate(self, age: int, symptoms: List[str], vital_signs: Dict, 
                       medical_history: List[str], diagnosis: str = None) -> Dict:
        """Calculate comprehensive risk score"""
        try:
            # Calculate individual risk components
            age_risk = self._calculate_age_risk(age)
            vitals_risk = self._calculate_vitals_risk(vital_signs)
            symptoms_risk = self._calculate_symptoms_risk(symptoms)
            history_risk = self._calculate_history_risk(medical_history)
            
            # Calculate weighted total risk (0-100)
            total_risk = (
                age_risk * 0.20 +
                vitals_risk * 0.30 +
                symptoms_risk * 0.30 +
                history_risk * 0.20
            )
            
            # Determine risk level
            risk_level = self._get_risk_level(total_risk)
            
            # Calculate 30-day mortality risk
            mortality_risk = self._calculate_mortality_risk(total_risk, diagnosis)
            
            # Generate recommendations
            recommendations = self._generate_recommendations(total_risk, risk_level)
            
            return {
                "risk_score": round(total_risk, 2),
                "risk_level": risk_level,
                "risk_factors": self._identify_risk_factors(age, vital_signs, symptoms, medical_history),
                "mortality_risk_30d": round(mortality_risk, 2),
                "recommended_actions": recommendations
            }
            
        except Exception as e:
            logger.error(f"Risk calculation error: {str(e)}")
            return self._get_default_risk_response()
    
    def interpret_score(self, score: float) -> Dict:
        """Interpret risk score"""
        if score < 20:
            return {"level": "Low", "color": "green", "action": "Routine care"}
        elif score < 50:
            return {"level": "Moderate", "color": "yellow", "action": "Close monitoring"}
        elif score < 75:
            return {"level": "High", "color": "orange", "action": "Urgent evaluation"}
        else:
            return {"level": "Critical", "color": "red", "action": "Immediate intervention"}
    
    def _calculate_age_risk(self, age: int) -> float:
        """Calculate risk based on age"""
        if not age:
            return 10.0
        if age < 18:
            return 5.0
        elif age < 40:
            return 10.0
        elif age < 60:
            return 30.0
        elif age < 75:
            return 60.0
        else:
            return 85.0
    
    def _calculate_vitals_risk(self, vitals: Dict) -> float:
        """Calculate risk based on vital signs"""
        risk = 0
        if not vitals:
            return 20.0
            
        # Blood pressure
        if 'bp_systolic' in vitals and vitals['bp_systolic']:
            if vitals['bp_systolic'] > 180:
                risk += 40
            elif vitals['bp_systolic'] > 140:
                risk += 20
        
        # Heart rate
        if 'heart_rate' in vitals and vitals['heart_rate']:
            if vitals['heart_rate'] > 120 or vitals['heart_rate'] < 50:
                risk += 30
        
        # Temperature
        if 'temperature' in vitals and vitals['temperature']:
            if vitals['temperature'] > 39 or vitals['temperature'] < 35:
                risk += 30
        
        return min(risk, 100)
    
    def _calculate_symptoms_risk(self, symptoms: List[str]) -> float:
        """Calculate risk based on symptoms"""
        high_risk_symptoms = ['chest pain', 'difficulty breathing', 'severe bleeding', 
                             'loss of consciousness', 'seizure']
        
        medium_risk_symptoms = ['fever', 'vomiting', 'severe pain', 'confusion']
        
        risk = 0
        for symptom in symptoms:
            symptom_lower = symptom.lower() if symptom else ""
            if any(high in symptom_lower for high in high_risk_symptoms):
                risk += 30
            elif any(medium in symptom_lower for medium in medium_risk_symptoms):
                risk += 15
        
        return min(risk, 100) if risk > 0 else 25.0
    
    def _calculate_history_risk(self, medical_history: List[str]) -> float:
        """Calculate risk based on medical history"""
        high_risk_conditions = ['heart disease', 'diabetes', 'cancer', 'stroke', 'kidney disease']
        
        risk = 0
        for condition in medical_history:
            condition_lower = condition.lower() if condition else ""
            if condition_lower in high_risk_conditions:
                risk += 25
        
        return min(risk, 100)
    
    def _get_risk_level(self, risk_score: float) -> str:
        """Determine risk level from score"""
        if risk_score < 20:
            return "Low"
        elif risk_score < 50:
            return "Moderate"
        elif risk_score < 75:
            return "High"
        else:
            return "Critical"
    
    def _calculate_mortality_risk(self, total_risk: float, diagnosis: str = None) -> float:
        """Calculate 30-day mortality risk"""
        base_risk = total_risk / 100 * 10
        
        # Fix: Handle None or empty diagnosis
        if diagnosis and isinstance(diagnosis, str):
            high_mortality_dx = ['sepsis', 'heart attack', 'stroke', 'pneumonia']
            if any(dx in diagnosis.lower() for dx in high_mortality_dx):
                base_risk *= 2
        
        return min(base_risk, 50)
    
    def _identify_risk_factors(self, age: int, vitals: Dict, symptoms: List[str], history: List[str]) -> List[str]:
        """Identify specific risk factors"""
        factors = []
        
        if age and age > 65:
            factors.append("Advanced age (>65 years)")
        
        if vitals and vitals.get('bp_systolic', 0) and vitals.get('bp_systolic', 0) > 160:
            factors.append("Severe hypertension")
        
        symptom_str = ' '.join(symptoms).lower() if symptoms else ""
        if 'chest pain' in symptom_str or 'difficulty breathing' in symptom_str:
            factors.append("Cardiorespiratory symptoms")
        
        history_str = ' '.join(history).lower() if history else ""
        if 'diabetes' in history_str:
            factors.append("Diabetes mellitus")
        
        if 'hypertension' in history_str:
            factors.append("History of hypertension")
        
        if not factors:
            factors.append("No major risk factors identified")
        
        return factors
    
    def _generate_recommendations(self, risk_score: float, risk_level: str) -> List[str]:
        """Generate recommendations based on risk level"""
        recommendations = []
        
        if risk_level == "Critical":
            recommendations.extend([
                "Immediate emergency department referral",
                "Activate rapid response team",
                "Continuous vital signs monitoring"
            ])
        elif risk_level == "High":
            recommendations.extend([
                "Urgent medical evaluation within 24 hours",
                "Consider hospitalization",
                "Frequent monitoring of vital signs"
            ])
        elif risk_level == "Moderate":
            recommendations.extend([
                "Schedule medical appointment within 1 week",
                "Monitor symptoms daily",
                "Lifestyle modifications as appropriate"
            ])
        else:
            recommendations.extend([
                "Routine follow-up as needed",
                "Continue current management",
                "Health maintenance education"
            ])
        
        return recommendations
    
    def _get_default_risk_response(self) -> Dict:
        """Return default risk response on error"""
        return {
            "risk_score": 25.0,
            "risk_level": "Moderate",
            "risk_factors": ["Unable to calculate all factors"],
            "mortality_risk_30d": 5.0,
            "recommended_actions": ["Consult healthcare provider for accurate assessment"]
        }