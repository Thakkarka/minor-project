from typing import List, Dict, Any
from loguru import logger
import re

class SymptomAnalyzer:
    def __init__(self):
        pass
        
    async def analyze(self, symptoms: str, patient_age: int = None, 
                     patient_gender: str = None, medical_history: List[str] = None) -> Dict:
        """Analyze symptoms and return structured information"""
        
        logger.info(f"Analyzing symptoms: {symptoms[:100]}...")
        
        # Simple parsing of symptoms
        symptoms_lower = symptoms.lower()
        
        # Extract symptoms based on keywords
        extracted = []
        symptom_keywords = {
            'fever': ['fever', 'high temperature', 'hot', 'chills'],
            'headache': ['headache', 'head pain', 'migraine'],
            'cough': ['cough', 'coughing'],
            'fatigue': ['fatigue', 'tired', 'exhausted', 'weak'],
            'nausea': ['nausea', 'queasy', 'sick to stomach'],
            'chest pain': ['chest pain', 'chest tightness', 'heart pain'],
            'shortness of breath': ['shortness of breath', 'difficulty breathing', 'can\'t breathe'],
            'dizziness': ['dizzy', 'dizziness', 'lightheaded'],
            'sore throat': ['sore throat', 'scratchy throat'],
            'runny nose': ['runny nose', 'congestion', 'stuffy nose']
        }
        
        for symptom, keywords in symptom_keywords.items():
            if any(keyword in symptoms_lower for keyword in keywords):
                extracted.append({
                    "symptom": symptom,
                    "description": symptom,
                    "severity": "moderate"
                })
        
        if not extracted:
            extracted = [{"symptom": symptoms[:50], "description": symptoms[:50], "severity": "moderate"}]
        
        # Calculate severity based on keywords
        severity = 50
        if any(word in symptoms_lower for word in ['severe', 'excruciating', 'intense', 'worst']):
            severity = 85
        elif any(word in symptoms_lower for word in ['mild', 'slight', 'little']):
            severity = 25
        
        # Estimate duration
        duration = 3
        import re
        day_match = re.search(r'(\d+)\s*(?:day|days?)', symptoms_lower)
        if day_match:
            duration = int(day_match.group(1))
        
        # Identify body systems
        body_systems = []
        system_map = {
            'headache': 'nervous',
            'dizziness': 'nervous',
            'chest pain': 'cardiovascular',
            'shortness of breath': 'respiratory',
            'cough': 'respiratory',
            'fever': 'general',
            'fatigue': 'general',
            'nausea': 'digestive'
        }
        
        for symptom in extracted:
            system = system_map.get(symptom['symptom'], 'general')
            if system not in body_systems:
                body_systems.append(system)
        
        if not body_systems:
            body_systems = ['general']
        
        return {
            "symptoms_raw": symptoms,
            "symptoms_structured": extracted,
            "severity_score": float(severity),
            "duration_days": duration,
            "body_systems_affected": body_systems,
            "gemini_analysis": {"status": "mock_mode", "message": "Analysis completed"}
        }