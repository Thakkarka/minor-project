import uuid
from datetime import datetime
from typing import Dict, Any
import json

def generate_id(prefix: str = "") -> str:
    """Generate unique ID"""
    unique_id = str(uuid.uuid4())[:8]
    if prefix:
        return f"{prefix}_{unique_id}"
    return unique_id

def format_response(data: Any, success: bool = True, message: str = "") -> Dict:
    """Format API response"""
    return {
        "success": success,
        "message": message,
        "data": data,
        "timestamp": datetime.utcnow().isoformat()
    }

def calculate_age_from_dob(dob: str) -> int:
    """Calculate age from date of birth"""
    try:
        birth_date = datetime.strptime(dob, "%Y-%m-%d")
        today = datetime.now()
        age = today.year - birth_date.year
        if today.month < birth_date.month or (today.month == birth_date.month and today.day < birth_date.day):
            age -= 1
        return age
    except:
        return 0

def validate_medical_data(data: Dict) -> bool:
    """Validate medical data structure"""
    required_fields = ['patient_id', 'symptoms']
    for field in required_fields:
        if field not in data:
            return False
    return True

def mask_patient_id(patient_id: str) -> str:
    """Mask patient ID for logging"""
    if len(patient_id) > 4:
        return f"***{patient_id[-4:]}"
    return "***"

def serialize_datetime(obj: Any) -> Any:
    """Helper for JSON serialization of datetime objects"""
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Type {type(obj)} not serializable")