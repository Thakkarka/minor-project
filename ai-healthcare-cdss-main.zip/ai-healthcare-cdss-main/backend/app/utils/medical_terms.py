from typing import List, Dict

# Medical term mappings
SYMPTOM_SYNONYMS = {
    'headache': ['cephalalgia', 'head pain', 'migraine', 'tension headache'],
    'fever': ['pyrexia', 'high temperature', 'febrile', 'hyperthermia'],
    'cough': ['tussis', 'hacking', 'productive cough', 'dry cough'],
    'nausea': ['queasy', 'sick to stomach', 'emesis', 'vomiting'],
    'fatigue': ['tiredness', 'lethargy', 'exhaustion', 'weakness'],
    'dizziness': ['vertigo', 'lightheadedness', 'unsteady', 'woozy'],
    'pain': ['ache', 'discomfort', 'soreness', 'stinging', 'throbbing']
}

BODY_SYSTEMS = {
    'nervous': ['headache', 'dizziness', 'seizure', 'numbness', 'tingling'],
    'respiratory': ['cough', 'shortness of breath', 'wheezing', 'chest tightness'],
    'cardiovascular': ['chest pain', 'palpitations', 'irregular heartbeat'],
    'digestive': ['nausea', 'vomiting', 'diarrhea', 'constipation', 'abdominal pain'],
    'musculoskeletal': ['joint pain', 'muscle ache', 'back pain', 'stiffness'],
    'general': ['fever', 'fatigue', 'weight loss', 'sweating']
}

def get_symptom_synonyms(symptom: str) -> List[str]:
    """Get synonyms for a symptom"""
    symptom_lower = symptom.lower()
    for main_symptom, synonyms in SYMPTOM_SYNONYMS.items():
        if symptom_lower == main_symptom or symptom_lower in synonyms:
            return [main_symptom] + synonyms
    return [symptom]

def map_to_standard_term(symptom: str) -> str:
    """Map a symptom to its standard medical term"""
    symptom_lower = symptom.lower()
    for standard_term, synonyms in SYMPTOM_SYNONYMS.items():
        if symptom_lower == standard_term or symptom_lower in synonyms:
            return standard_term
    return symptom_lower

def get_body_system_for_symptom(symptom: str) -> str:
    """Determine which body system a symptom belongs to"""
    symptom_lower = symptom.lower()
    for system, symptoms in BODY_SYSTEMS.items():
        if any(s in symptom_lower for s in symptoms):
            return system
    return "general"

def get_common_differentials(symptom: str) -> List[str]:
    """Get common differential diagnoses for a symptom"""
    # Simplified mapping - in production, this would be more comprehensive
    differentials = {
        'headache': ['Tension headache', 'Migraine', 'Sinusitis', 'Cluster headache'],
        'chest pain': ['Angina', 'GERD', 'Musculoskeletal', 'Anxiety'],
        'fever': ['Viral infection', 'Bacterial infection', 'Inflammatory condition'],
        'cough': ['URTI', 'Bronchitis', 'Asthma', 'Allergies']
    }
    
    symptom_lower = symptom.lower()
    for key, diffs in differentials.items():
        if key in symptom_lower:
            return diffs
    
    return ['Further evaluation needed']