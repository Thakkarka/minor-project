import re
from typing import List, Dict
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

# Download NLTK data if needed
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')
    nltk.download('stopwords')

def process_text(text: str) -> Dict[str, any]:
    """Process and analyze text"""
    if not text:
        return {"words": [], "sentences": [], "processed": ""}
    
    # Tokenize
    sentences = nltk.sent_tokenize(text)
    words = nltk.word_tokenize(text.lower())
    
    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    filtered_words = [w for w in words if w.isalnum() and w not in stop_words]
    
    return {
        "original": text,
        "words": words,
        "filtered_words": filtered_words,
        "sentences": sentences,
        "word_count": len(words),
        "sentence_count": len(sentences)
    }

def extract_medical_entities(text: str) -> List[Dict]:
    """Extract medical entities from text"""
    entities = []
    
    # Medical patterns
    patterns = {
        'symptom': r'\b(?:pain|fever|cough|headache|nausea|fatigue|dizziness|rash|swelling)\b',
        'medication': r'\b(?:aspirin|ibuprofen|paracetamol|antibiotic|insulin)\b',
        'condition': r'\b(?:diabetes|hypertension|asthma|arthritis|cancer)\b',
        'vital_sign': r'\b(?:temperature|blood pressure|heart rate|oxygen saturation)\b'
    }
    
    for entity_type, pattern in patterns.items():
        matches = re.finditer(pattern, text.lower())
        for match in matches:
            entities.append({
                "type": entity_type,
                "value": match.group(),
                "position": match.span()
            })
    
    return entities

def extract_symptom_attributes(symptom_text: str) -> Dict:
    """Extract attributes from symptom description"""
    attributes = {
        "duration": None,
        "severity": None,
        "location": None,
        "quality": None
    }
    
    # Duration patterns
    duration_match = re.search(r'(\d+)\s*(?:day|week|month)s?', symptom_text.lower())
    if duration_match:
        attributes["duration"] = duration_match.group(0)
    
    # Severity patterns
    if re.search(r'severe|excruciating|intense', symptom_text.lower()):
        attributes["severity"] = "severe"
    elif re.search(r'mild|slight|little', symptom_text.lower()):
        attributes["severity"] = "mild"
    else:
        attributes["severity"] = "moderate"
    
    # Location patterns
    location_patterns = ['head', 'chest', 'abdomen', 'back', 'neck', 'leg', 'arm']
    for location in location_patterns:
        if location in symptom_text.lower():
            attributes["location"] = location
            break
    
    return attributes