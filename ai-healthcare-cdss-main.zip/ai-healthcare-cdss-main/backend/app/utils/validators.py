from typing import List, Dict, Any
import re

def validate_symptoms(symptoms: str) -> Dict[str, Any]:
    """Validate and sanitize symptom input"""
    if not symptoms or not isinstance(symptoms, str):
        return {"valid": False, "error": "Symptoms must be a non-empty string"}
    
    if len(symptoms) > 5000:
        return {"valid": False, "error": "Symptoms input too long (max 5000 characters)"}
    
    # Remove potentially harmful content
    cleaned = re.sub(r'[<>{}]', '', symptoms)
    
    return {"valid": True, "cleaned_symptoms": cleaned}

def validate_patient_data(patient_data: Dict[str, Any]) -> Dict[str, Any]:
    """Validate patient data"""
    errors = []
    
    # Validate age
    if 'age' in patient_data:
        age = patient_data['age']
        if not isinstance(age, (int, float)) or age < 0 or age > 150:
            errors.append("Invalid age")
    
    # Validate gender
    if 'gender' in patient_data:
        gender = patient_data['gender'].lower()
        if gender not in ['male', 'female', 'other']:
            errors.append("Invalid gender")
    
    # Validate vital signs
    if 'vital_signs' in patient_data:
        vitals = patient_data['vital_signs']
        if 'temperature' in vitals:
            temp = vitals['temperature']
            if temp < 32 or temp > 45:
                errors.append("Invalid temperature")
        
        if 'heart_rate' in vitals:
            hr = vitals['heart_rate']
            if hr < 30 or hr > 220:
                errors.append("Invalid heart rate")
    
    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "cleaned_data": patient_data if len(errors) == 0 else None
    }

def sanitize_input(text: str) -> str:
    """Sanitize user input"""
    if not text:
        return ""
    
    # Remove HTML tags
    text = re.sub(r'<[^>]*>', '', text)
    
    # Remove script tags
    text = re.sub(r'<script.*?</script>', '', text, flags=re.DOTALL)
    
    # Escape special characters
    text = text.replace('&', '&amp;')
    text = text.replace('<', '&lt;')
    text = text.replace('>', '&gt;')
    
    return text.strip()