import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_root_endpoint():
    response = client.get("/")
    assert response.status_code == 200
    assert "message" in response.json()

def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"

def test_symptom_analysis():
    test_data = {
        "patient_id": "test_001",
        "symptoms": "Patient has fever and headache for 2 days",
        "patient_age": 35,
        "patient_gender": "male"
    }
    response = client.post("/api/symptoms/analyze", json=test_data)
    assert response.status_code == 200
    data = response.json()
    assert "severity_score" in data

def test_differential_diagnosis():
    test_data = {
        "patient_id": "test_001",
        "symptoms": ["fever", "cough", "fatigue"],
        "patient_age": 45
    }
    response = client.post("/api/diagnosis/differential", json=test_data)
    assert response.status_code == 200
    data = response.json()
    assert "primary_diagnosis" in data

def test_risk_calculation():
    test_data = {
        "age": 65,
        "symptoms": ["chest pain", "shortness of breath"],
        "vital_signs": {"bp_systolic": 160, "heart_rate": 100},
        "medical_history": ["hypertension", "diabetes"]
    }
    response = client.post("/api/risk/calculate", json=test_data)
    assert response.status_code == 200
    data = response.json()
    assert "risk_score" in data
    assert "risk_level" in data

def test_literature_search():
    test_data = {
        "query": "hypertension treatment",
        "top_k": 3
    }
    response = client.post("/api/literature/search", json=test_data)
    assert response.status_code == 200
    data = response.json()
    assert "results" in data

def test_chat():
    test_data = {
        "message": "What are the symptoms of diabetes?",
        "session_id": "test_session"
    }
    response = client.post("/api/chat/message", json=test_data)
    assert response.status_code == 200
    data = response.json()
    assert "response" in data

def test_feedback():
    test_data = {
        "diagnosis_id": "test_dx_001",
        "patient_id": "test_001",
        "accuracy_rating": 4,
        "helpfulness_rating": 5,
        "comments": "Good suggestions"
    }
    response = client.post("/api/feedback/submit", json=test_data)
    assert response.status_code == 200
    assert response.json()["status"] == "success"