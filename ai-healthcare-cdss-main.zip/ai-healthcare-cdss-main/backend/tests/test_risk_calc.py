import pytest
from app.services.risk_calculator import RiskCalculator

def test_age_risk():
    calculator = RiskCalculator()
    
    # Test different age groups
    young_risk = calculator._calculate_age_risk(25)
    middle_risk = calculator._calculate_age_risk(50)
    old_risk = calculator._calculate_age_risk(80)
    
    assert young_risk < middle_risk < old_risk
    assert 0 <= young_risk <= 100

def test_vitals_risk():
    calculator = RiskCalculator()
    
    # Normal vitals
    normal_vitals = {"bp_systolic": 120, "heart_rate": 75, "temperature": 37}
    normal_risk = calculator._calculate_vitals_risk(normal_vitals)
    
    # Abnormal vitals
    abnormal_vitals = {"bp_systolic": 190, "heart_rate": 130, "temperature": 39.5}
    abnormal_risk = calculator._calculate_vitals_risk(abnormal_vitals)
    
    assert abnormal_risk > normal_risk

def test_symptom_risk():
    calculator = RiskCalculator()
    
    # Low risk symptoms
    low_risk_symptoms = ["mild headache", "slight fatigue"]
    low_risk = calculator._calculate_symptoms_risk(low_risk_symptoms)
    
    # High risk symptoms
    high_risk_symptoms = ["chest pain", "difficulty breathing"]
    high_risk = calculator._calculate_symptoms_risk(high_risk_symptoms)
    
    assert high_risk > low_risk

def test_risk_levels():
    calculator = RiskCalculator()
    
    assert calculator._get_risk_level(10) == "Low"
    assert calculator._get_risk_level(35) == "Moderate"
    assert calculator._get_risk_level(60) == "High"
    assert calculator._get_risk_level(85) == "Critical"

def test_risk_factor_identification():
    calculator = RiskCalculator()
    
    factors = calculator._identify_risk_factors(
        age=70,
        vitals={"bp_systolic": 165},
        symptoms=["chest pain"],
        history=["diabetes"]
    )
    
    assert len(factors) > 0
    assert any("Advanced age" in f for f in factors)
    assert any("hypertension" in f.lower() for f in factors)