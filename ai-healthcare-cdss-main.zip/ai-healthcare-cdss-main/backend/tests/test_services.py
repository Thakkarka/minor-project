import pytest
from app.services.symptom_analyzer import SymptomAnalyzer
from app.services.risk_calculator import RiskCalculator
from app.services.cache_service import CacheService

@pytest.mark.asyncio
async def test_symptom_analyzer():
    analyzer = SymptomAnalyzer()
    result = await analyzer.analyze(
        symptoms="Severe headache and nausea for 3 days",
        patient_age=30
    )
    assert "severity_score" in result
    assert result["severity_score"] > 0

def test_risk_calculator():
    calculator = RiskCalculator()
    result = calculator.interpret_score(75)
    assert result["level"] == "High"

def test_cache_service():
    cache = CacheService(max_size=10, ttl=60)
    cache.set("test_key", "test_value")
    value = cache.get("test_key")
    assert value == "test_value"
    
    cache.delete("test_key")
    value = cache.get("test_key")
    assert value is None

def test_risk_calculation_sync():
    import asyncio
    calculator = RiskCalculator()
    
    async def test():
        return await calculator.calculate(
            age=70,
            symptoms=["chest pain"],
            vital_signs={"bp_systolic": 180},
            medical_history=["heart disease"],
            diagnosis="Angina"
        )
    
    result = asyncio.run(test())
    assert result["risk_score"] > 0
    assert result["risk_level"] in ["Low", "Moderate", "High", "Critical"]