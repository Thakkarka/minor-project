﻿import sqlite3

conn = sqlite3.connect('sqlite.db')
cursor = conn.cursor()

# List all tables
cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
tables = cursor.fetchall()
print("Tables in database:")
for table in tables:
    print(f"  - {table[0]}")

# Check symptom_analyses table structure
cursor.execute("PRAGMA table_info(symptom_analyses);")
columns = cursor.fetchall()
print("\nsymptom_analyses columns:")
for col in columns:
    print(f"  - {col[1]} ({col[2]})")

conn.close()