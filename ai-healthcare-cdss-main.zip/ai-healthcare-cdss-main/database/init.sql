-- Initialize database with all tables
-- Run all migration files in order

.read migrations/001_create_symptoms_table.sql
.read migrations/002_create_diagnoses_table.sql
.read migrations/003_create_risk_assessments_table.sql
.read migrations/004_create_literature_cache_table.sql
.read migrations/005_create_feedback_table.sql
.read migrations/006_create_patients_table.sql
.read migrations/007_create_sessions_table.sql

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_symptoms_patient_date ON symptom_analyses(patient_id, created_at);
CREATE INDEX IF NOT EXISTS idx_diagnoses_patient_date ON diagnoses(patient_id, created_at);
CREATE INDEX IF NOT EXISTS idx_risk_patient_date ON risk_assessments(patient_id, created_at);

-- Create view for dashboard statistics
CREATE VIEW IF NOT EXISTS dashboard_stats AS
SELECT 
    (SELECT COUNT(*) FROM symptom_analyses) as total_symptom_analyses,
    (SELECT COUNT(*) FROM diagnoses) as total_diagnoses,
    (SELECT COUNT(*) FROM risk_assessments) as total_risk_assessments,
    (SELECT COUNT(*) FROM feedback) as total_feedback,
    (SELECT COUNT(*) FROM patients) as total_patients;