-- Create symptoms table
CREATE TABLE IF NOT EXISTS symptom_analyses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id VARCHAR(255) NOT NULL,
    symptoms_raw TEXT NOT NULL,
    symptoms_structured TEXT,
    severity_score FLOAT DEFAULT 0,
    duration_days INTEGER DEFAULT 0,
    body_systems_affected TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes separately
CREATE INDEX IF NOT EXISTS idx_symptom_patient_id ON symptom_analyses(patient_id);
CREATE INDEX IF NOT EXISTS idx_symptom_created_at ON symptom_analyses(created_at);

-- Create trigger for updated_at
CREATE TRIGGER IF NOT EXISTS update_symptom_analyses_updated_at 
    AFTER UPDATE ON symptom_analyses
    BEGIN
        UPDATE symptom_analyses SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
    END;