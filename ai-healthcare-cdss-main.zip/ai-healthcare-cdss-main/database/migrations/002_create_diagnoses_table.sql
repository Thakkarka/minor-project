-- Create diagnoses table
CREATE TABLE IF NOT EXISTS diagnoses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id VARCHAR(255) NOT NULL,
    symptom_analysis_id INTEGER,
    primary_diagnosis VARCHAR(500),
    differential_diagnoses TEXT,
    confidence_score FLOAT DEFAULT 0,
    recommended_tests TEXT,
    treatment_suggestions TEXT,
    clinical_reasoning TEXT,
    evidence_level VARCHAR(100),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (symptom_analysis_id) REFERENCES symptom_analyses(id)
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_diagnosis_patient_id ON diagnoses(patient_id);
CREATE INDEX IF NOT EXISTS idx_diagnosis_created_at ON diagnoses(created_at);
CREATE INDEX IF NOT EXISTS idx_diagnosis_primary ON diagnoses(primary_diagnosis);
CREATE INDEX IF NOT EXISTS idx_diagnosis_confidence ON diagnoses(confidence_score);