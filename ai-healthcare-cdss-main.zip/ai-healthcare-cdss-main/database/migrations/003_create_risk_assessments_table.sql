-- Create risk assessments table
CREATE TABLE IF NOT EXISTS risk_assessments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id VARCHAR(255) NOT NULL,
    diagnosis_id INTEGER,
    risk_score FLOAT DEFAULT 0,
    risk_level VARCHAR(50),
    risk_factors TEXT,
    mortality_risk_30d FLOAT DEFAULT 0,
    recommended_actions TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (diagnosis_id) REFERENCES diagnoses(id)
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_risk_patient_id ON risk_assessments(patient_id);
CREATE INDEX IF NOT EXISTS idx_risk_score ON risk_assessments(risk_score);
CREATE INDEX IF NOT EXISTS idx_risk_level ON risk_assessments(risk_level);
CREATE INDEX IF NOT EXISTS idx_risk_created_at ON risk_assessments(created_at);