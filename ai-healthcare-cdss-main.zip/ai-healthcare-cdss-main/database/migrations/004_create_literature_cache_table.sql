-- Create literature cache table
CREATE TABLE IF NOT EXISTS literature_cache (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    query_hash VARCHAR(64) UNIQUE NOT NULL,
    query_text TEXT NOT NULL,
    results TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_lit_query_hash ON literature_cache(query_hash);
CREATE INDEX IF NOT EXISTS idx_lit_expires_at ON literature_cache(expires_at);