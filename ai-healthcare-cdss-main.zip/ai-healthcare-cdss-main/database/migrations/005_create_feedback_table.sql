-- Create feedback table
CREATE TABLE IF NOT EXISTS feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    diagnosis_id VARCHAR(255),
    patient_id VARCHAR(255) NOT NULL,
    accuracy_rating INTEGER,
    helpfulness_rating INTEGER,
    comments TEXT,
    suggested_diagnosis VARCHAR(500),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_feedback_diagnosis_id ON feedback(diagnosis_id);
CREATE INDEX IF NOT EXISTS idx_feedback_patient_id ON feedback(patient_id);
CREATE INDEX IF NOT EXISTS idx_feedback_created_at ON feedback(created_at);