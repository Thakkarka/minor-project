-- Create patients table
CREATE TABLE IF NOT EXISTS patients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id VARCHAR(255) UNIQUE NOT NULL,
    age INTEGER,
    gender VARCHAR(50),
    medical_history TEXT,
    medications TEXT,
    allergies TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_patient_id ON patients(patient_id);
CREATE INDEX IF NOT EXISTS idx_patient_age ON patients(age);
CREATE INDEX IF NOT EXISTS idx_patient_gender ON patients(gender);

-- Create trigger for updated_at
CREATE TRIGGER IF NOT EXISTS update_patients_updated_at 
    AFTER UPDATE ON patients
    BEGIN
        UPDATE patients SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
    END;