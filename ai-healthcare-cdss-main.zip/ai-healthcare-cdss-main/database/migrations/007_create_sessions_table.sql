-- Create chat sessions table
CREATE TABLE IF NOT EXISTS chat_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id VARCHAR(255) UNIQUE NOT NULL,
    patient_id VARCHAR(255),
    messages TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_session_id ON chat_sessions(session_id);
CREATE INDEX IF NOT EXISTS idx_session_patient_id ON chat_sessions(patient_id);
CREATE INDEX IF NOT EXISTS idx_session_expires_at ON chat_sessions(expires_at);

-- Create trigger for updated_at
CREATE TRIGGER IF NOT EXISTS update_chat_sessions_updated_at 
    AFTER UPDATE ON chat_sessions
    BEGIN
        UPDATE chat_sessions SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
    END;