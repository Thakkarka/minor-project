#!/usr/bin/env python3
"""
Database seeding script - Populates database with mock data
"""

import sqlite3
import json
from datetime import datetime, timedelta
import random
import os

DB_PATH = "sqlite.db"

def seed_database():
    """Seed database with realistic mock data"""
    
    if not os.path.exists(DB_PATH):
        print("Database not found. Please run setup_db.py first")
        return
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Check if data already exists
    cursor.execute("SELECT COUNT(*) FROM patients")
    count = cursor.fetchone()[0]
    
    if count > 0:
        print("Database already has data. Skipping seed.")
        conn.close()
        return
    
    # Sample patients
    patients = [
        ("PAT_001", 45, "male", '["hypertension"]', '["lisinopril"]', '[]'),
        ("PAT_002", 32, "female", '["asthma"]', '["albuterol"]', '["penicillin"]'),
        ("PAT_003", 68, "male", '["copd", "heart_failure"]', '["furosemide", "spiriva"]', '[]'),
        ("PAT_004", 27, "female", '["migraine"]', '["sumatriptan"]', '[]'),
        ("PAT_005", 55, "female", '["hypothyroidism"]', '["levothyroxine"]', '[]'),
    ]
    
    for patient in patients:
        cursor.execute("""
            INSERT OR IGNORE INTO patients (patient_id, age, gender, medical_history, medications, allergies)
            VALUES (?, ?, ?, ?, ?, ?)
        """, patient)
    
    # Sample symptom analyses
    symptom_data = [
        ("PAT_001", "Severe headache for 3 days, nausea", 
         '[{"symptom": "headache", "severity": "severe"}, {"symptom": "nausea", "severity": "moderate"}]',
         75, 3, '["nervous"]'),
        ("PAT_002", "Cough and fever for 2 days",
         '[{"symptom": "cough", "severity": "moderate"}, {"symptom": "fever", "severity": "moderate"}]',
         45, 2, '["respiratory"]'),
        ("PAT_003", "Shortness of breath, chest tightness",
         '[{"symptom": "shortness of breath", "severity": "severe"}, {"symptom": "chest tightness", "severity": "moderate"}]',
         85, 1, '["respiratory", "cardiovascular"]'),
    ]
    
    for data in symptom_data:
        cursor.execute("""
            INSERT INTO symptom_analyses (patient_id, symptoms_raw, symptoms_structured, severity_score, duration_days, body_systems_affected)
            VALUES (?, ?, ?, ?, ?, ?)
        """, data)
    
    # Sample diagnoses
    diagnoses = [
        ("PAT_001", "Migraine", 
         '[{"condition": "Migraine", "probability": 0.7}, {"condition": "Tension headache", "probability": 0.2}]',
         0.75, '["Neurological exam", "MRI if recurrent"]', '["Rest", "Hydration", "NSAIDs"]'),
        ("PAT_002", "Upper Respiratory Infection",
         '[{"condition": "URI", "probability": 0.8}, {"condition": "Influenza", "probability": 0.15}]',
         0.70, '["CBC", "Rapid strep"]', '["Rest", "Fluids", "Symptomatic treatment"]'),
    ]
    
    for diagnosis in diagnoses:
        cursor.execute("""
            INSERT INTO diagnoses (patient_id, primary_diagnosis, differential_diagnoses, confidence_score, recommended_tests, treatment_suggestions)
            VALUES (?, ?, ?, ?, ?, ?)
        """, diagnosis)
    
    # Get the inserted IDs
    cursor.execute("SELECT id, patient_id FROM diagnoses")
    diagnosis_ids = cursor.fetchall()
    
    # Sample risk assessments
    risks = [
        ("PAT_001", 25.0, "Low", '["Age <40", "No comorbidities"]', 5.0, '["Routine follow-up"]'),
        ("PAT_003", 85.0, "Critical", '["Age >65", "COPD", "Heart failure"]', 35.0, '["Immediate hospitalization", "Cardiology consult"]'),
    ]
    
    for risk in risks:
        cursor.execute("""
            INSERT INTO risk_assessments (patient_id, risk_score, risk_level, risk_factors, mortality_risk_30d, recommended_actions)
            VALUES (?, ?, ?, ?, ?, ?)
        """, risk)
    
    # Sample feedback
    feedbacks = [
        ("DX_001", "PAT_001", 5, 5, "Very accurate diagnosis", None),
        ("DX_002", "PAT_002", 4, 4, "Helpful suggestions", None),
    ]
    
    for feedback in feedbacks:
        cursor.execute("""
            INSERT INTO feedback (diagnosis_id, patient_id, accuracy_rating, helpfulness_rating, comments, suggested_diagnosis)
            VALUES (?, ?, ?, ?, ?, ?)
        """, feedback)
    
    conn.commit()
    conn.close()
    
    print("✅ Database seeded successfully with mock data")
    print(f"Seeded: {len(patients)} patients, {len(symptom_data)} symptoms, {len(diagnoses)} diagnoses")

if __name__ == "__main__":
    seed_database()