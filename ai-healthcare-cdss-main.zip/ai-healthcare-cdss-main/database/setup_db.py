
import sqlite3
import json
import os
from pathlib import Path
import sys

def setup_database():
    """Initialize database with all tables and seed data"""
    
    db_path = "sqlite.db"
    
    # Remove existing database if it exists
    if os.path.exists(db_path):
        os.remove(db_path)
        print(f"Removed existing database: {db_path}")
    
    # Connect to database
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Run migration files in order
    migration_dir = Path("migrations")
    if not migration_dir.exists():
        print("Error: migrations directory not found!")
        sys.exit(1)
    
    migration_files = sorted(migration_dir.glob("*.sql"))
    
    for migration_file in migration_files:
        print(f"Running migration: {migration_file.name}")
        with open(migration_file, 'r', encoding='utf-8') as f:
            sql_script = f.read()
            try:
                cursor.executescript(sql_script)
            except sqlite3.OperationalError as e:
                print(f"Warning: {e}")
                continue
    
    print("All migrations completed successfully")
    
    # Commit changes
    conn.commit()
    conn.close()
    
    print(f"Database setup complete: {db_path}")
    return True

if __name__ == "__main__":
    setup_database()