import sqlite3
import json

conn = sqlite3.connect('sqlite.db')
cursor = conn.cursor()

# Insert test data
cursor.execute('''
    INSERT INTO symptom_analyses (patient_id, symptoms_raw, symptoms_structured, severity_score, duration_days, body_systems_affected)
    VALUES (?, ?, ?, ?, ?, ?)
''', ('test123', 'test symptoms', json.dumps([{"symptom": "test"}]), 50, 2, json.dumps(["general"])))

conn.commit()

# Verify insert worked
cursor.execute("SELECT COUNT(*) FROM symptom_analyses")
count = cursor.fetchone()[0]
print(f"Found {count} records in symptom_analyses")

conn.close()
print("Database test successful!")