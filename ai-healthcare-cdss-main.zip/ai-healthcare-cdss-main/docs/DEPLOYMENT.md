# Deployment Guide

## Production Deployment Options

### Option 1: Traditional Deployment

#### Backend (Ubuntu Server)

1. Install Python and dependencies:
```bash
sudo apt update
sudo apt install python3.11 python3-pip nginx