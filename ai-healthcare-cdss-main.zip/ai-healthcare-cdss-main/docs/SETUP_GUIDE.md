

# Setup Guide

## Prerequisites

- Python 3.11+
- Node.js 18+
- Git
- Gemini API Key

## Backend Setup

### 1. Clone the repository
```bash
git clone <repository-url>
cd ai-healthcare-cdss