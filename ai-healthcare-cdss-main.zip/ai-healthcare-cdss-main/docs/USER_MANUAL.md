

# User Manual

## Overview

AI Healthcare CDSS is a clinical decision support system that helps healthcare professionals analyze symptoms, generate differential diagnoses, assess risks, and search medical literature.

## Getting Started

### Accessing the Application

1. Open your browser and navigate to `http://localhost:3000`
2. You'll see the dashboard with key metrics and quick actions

## Features

### 1. Symptom Checker

**Text Input Method:**
- Click "Symptom Checker" in navigation
- Type patient symptoms in the text area
- Click "Analyze Symptoms"
- View structured symptom analysis

**Symptom Selector Method:**
- Select from common symptoms dropdown
- Add custom symptoms if needed
- Click "Analyze Symptoms"

**Body Map Method:**
- Click on body areas
- Select associated symptoms
- Submit for analysis

### 2. Diagnosis

After symptom analysis, the system will:
- Generate primary diagnosis
- Show differential diagnoses with probabilities
- List recommended tests
- Provide treatment suggestions
- Display clinical reasoning

### 3. Risk Assessment

**Calculate Risk:**
- Enter patient age
- Input vital signs (optional)
- List symptoms
- Add medical history
- Click "Calculate Risk"

**Understanding Results:**
- Risk Score (0-100)
- Risk Level (Low/Moderate/High/Critical)
- Contributing Risk Factors
- 30-Day Mortality Risk
- Recommended Actions

### 4. Literature Search

- Enter search query (e.g., "hypertension treatment")
- Apply filters (year, article type)
- Click Search
- Click on articles to expand and read details
- Copy citations for reference

### 5. AI Chat Assistant

- Type medical questions
- Get AI-powered responses
- Use quick response buttons
- Clear chat history when needed

### 6. History

- View all past symptom analyses
- See severity scores
- Review previous diagnoses
- Track patient progress over time

### 7. Feedback

- Rate diagnosis accuracy (1-5 stars)
- Rate helpfulness
- Provide comments
- Suggest alternative diagnoses

## Tips for Best Results

1. **Be Specific**: Include symptom duration, severity, and context
2. **Complete Patient Info**: Age and medical history improve accuracy
3. **Use Structured Input**: Select from predefined symptoms when possible
4. **Verify Results**: Always cross-reference with clinical judgment
5. **Provide Feedback**: Helps improve the system

## Safety Information

⚠️ **Important**: 
- This is an AI-assisted tool, not a replacement for medical professionals
- Always verify recommendations with current guidelines
- Emergency symptoms require immediate medical attention
- The system may not have the latest medical information

## Support

For technical issues:
- Check console errors (F12)
- Verify backend is running
- Check API connectivity
- Review logs in `logs/` directory