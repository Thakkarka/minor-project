# AI Healthcare CDSS Frontend

## Setup Instructions

1. Install dependencies:
```bash
npm install