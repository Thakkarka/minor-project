import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AppProvider } from './context/AppContext';
import { ThemeProvider } from './context/ThemeContext';
import Layout from './components/Layout/Layout';
import HomePage from './pages/HomePage';
import SymptomChecker from './pages/SymptomChecker';
import DiagnosisPage from './pages/DiagnosisPage';
import RiskAssessment from './pages/RiskAssessment';
import LiteraturePage from './pages/LiteraturePage';
import ChatAssistant from './pages/ChatAssistant';
import HistoryPage from './pages/HistoryPage';
import AboutPage from './pages/AboutPage';
import FeedbackPage from './pages/FeedbackPage';

function App() {
  return (
    <ThemeProvider>
      <AppProvider>
        <Router>
          <Layout>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/symptom-checker" element={<SymptomChecker />} />
              <Route path="/diagnosis" element={<DiagnosisPage />} />
              <Route path="/risk-assessment" element={<RiskAssessment />} />
              <Route path="/literature" element={<LiteraturePage />} />
              <Route path="/chat" element={<ChatAssistant />} />
              <Route path="/history" element={<HistoryPage />} />
              <Route path="/about" element={<AboutPage />} />
              <Route path="/feedback" element={<FeedbackPage />} />
            </Routes>
          </Layout>
          <Toaster 
            position="top-right"
            toastOptions={{
              duration: 4000,
              style: {
                background: '#363636',
                color: '#fff',
              },
            }}
          />
        </Router>
      </AppProvider>
    </ThemeProvider>
  );
}

export default App;