import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import TextareaAutosize from 'react-textarea-autosize';
import { FiSend, FiRefreshCw } from 'react-icons/fi';
import MessageBubble from './MessageBubble';
import TypingIndicator from './TypingIndicator';
import QuickResponses from './QuickResponses';
import toast from 'react-hot-toast';

const ChatInterface = ({ onSendMessage, messages, loading, onClear, sessionId }) => {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!input.trim() || loading) return;
    
    const message = input.trim();
    setInput('');
    await onSendMessage(message);
    
    // Focus back on textarea
    setTimeout(() => {
      textareaRef.current?.focus();
    }, 100);
  };

  const handleQuickResponse = (response) => {
    setInput(response);
    textareaRef.current?.focus();
  };

  return (
    <div className="flex flex-col h-[600px] card">
      {/* Header */}
      <div className="flex justify-between items-center pb-4 border-b dark:border-gray-700">
        <div>
          <h3 className="font-semibold">AI Medical Assistant</h3>
          <p className="text-xs text-gray-500">Session: {sessionId?.slice(-8)}</p>
        </div>
        <button
          onClick={onClear}
          className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-all"
          title="Clear chat"
        >
          <FiRefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <AnimatePresence>
          {messages.map((message, index) => (
            <MessageBubble key={index} message={message} />
          ))}
          {loading && <TypingIndicator />}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Responses */}
      <QuickResponses onSelect={handleQuickResponse} />

      {/* Input */}
      <form onSubmit={handleSubmit} className="pt-4 border-t dark:border-gray-700">
        <div className="flex space-x-2">
          <TextareaAutosize
            ref={textareaRef}
            minRows={1}
            maxRows={4}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask me anything about medical conditions, treatments, or guidelines..."
            className="input-field resize-none"
            onKeyPress={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSubmit(e);
              }
            }}
            disabled={loading}
          />
          <button
            type="submit"
            disabled={loading || !input.trim()}
            className="btn-primary px-4 disabled:opacity-50"
          >
            <FiSend />
          </button>
        </div>
        <p className="text-xs text-gray-500 mt-2">
          ⚠️ AI-generated responses. Always verify with a healthcare professional.
        </p>
      </form>
    </div>
  );
};

export default ChatInterface;