import React from 'react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import ReactMarkdown from 'react-markdown';
import { FiUser, FiCpu } from 'react-icons/fi';

const MessageBubble = ({ message }) => {
  const isUser = message.role === 'user';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}
    >
      <div className={`flex max-w-[80%] ${isUser ? 'flex-row-reverse' : 'flex-row'} space-x-2`}>
        <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
          isUser ? 'bg-primary-600' : 'bg-gray-500'
        }`}>
          {isUser ? <FiUser className="text-white w-4 h-4" /> : <FiCpu className="text-white w-4 h-4" />}
        </div>
        <div>
          <div className={`rounded-lg p-3 ${
            isUser 
              ? 'bg-primary-600 text-white' 
              : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white'
          }`}>
            <ReactMarkdown className="prose prose-sm max-w-none dark:prose-invert">
              {message.content}
            </ReactMarkdown>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            {format(message.timestamp, 'h:mm a')}
          </p>
        </div>
      </div>
    </motion.div>
  );
};

export default MessageBubble;