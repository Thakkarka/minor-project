import React from 'react';
import { motion } from 'framer-motion';

const quickResponses = [
  "What are the symptoms of diabetes?",
  "Explain hypertension treatment",
  "Common side effects of antibiotics",
  "When to seek emergency care?",
  "How to manage fever at home?",
  "Prevention tips for heart disease",
];

const QuickResponses = ({ onSelect }) => {
  return (
    <div className="pb-4">
      <p className="text-xs text-gray-500 mb-2">Quick questions:</p>
      <div className="flex flex-wrap gap-2">
        {quickResponses.map((response, index) => (
          <motion.button
            key={index}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.05 }}
            onClick={() => onSelect(response)}
            className="px-3 py-1 text-xs bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-full transition-all"
          >
            {response}
          </motion.button>
        ))}
      </div>
    </div>
  );
};

export default QuickResponses;