import React from 'react';
import { motion } from 'framer-motion';
import { FiCpu } from 'react-icons/fi';

const TypingIndicator = () => {
  return (
    <div className="flex justify-start">
      <div className="flex space-x-2">
        <div className="w-8 h-8 rounded-full bg-gray-500 flex items-center justify-center">
          <FiCpu className="text-white w-4 h-4" />
        </div>
        <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-3">
          <div className="flex space-x-1">
            <motion.div
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 0.5, repeat: Infinity, delay: 0 }}
              className="w-2 h-2 bg-gray-400 rounded-full"
            />
            <motion.div
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 0.5, repeat: Infinity, delay: 0.2 }}
              className="w-2 h-2 bg-gray-400 rounded-full"
            />
            <motion.div
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 0.5, repeat: Infinity, delay: 0.4 }}
              className="w-2 h-2 bg-gray-400 rounded-full"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default TypingIndicator;