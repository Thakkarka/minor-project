import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiCheckCircle, FiAlertCircle, FiInfo, FiXCircle } from 'react-icons/fi';

const Toast = ({ message, type = 'info', onClose, duration = 3000 }) => {
  useEffect(() => {
    const timer = setTimeout(onClose, duration);
    return () => clearTimeout(timer);
  }, [duration, onClose]);

  const icons = {
    success: <FiCheckCircle className="text-green-500" />,
    error: <FiXCircle className="text-red-500" />,
    warning: <FiAlertCircle className="text-yellow-500" />,
    info: <FiInfo className="text-blue-500" />,
  };

  const bgColors = {
    success: 'bg-green-50 dark:bg-green-900/20 border-green-200',
    error: 'bg-red-50 dark:bg-red-900/20 border-red-200',
    warning: 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200',
    info: 'bg-blue-50 dark:bg-blue-900/20 border-blue-200',
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, x: 100 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: 100 }}
        className={`fixed bottom-4 right-4 z-50 flex items-center space-x-3 px-4 py-3 rounded-lg shadow-lg border ${bgColors[type]}`}
      >
        {icons[type]}
        <span className="text-sm">{message}</span>
      </motion.div>
    </AnimatePresence>
  );
};

export default Toast;