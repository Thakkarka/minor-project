import React from 'react';
import { motion } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';

const RecentActivities = ({ activities }) => {
  const defaultActivities = [
    { id: 1, action: 'Symptom analysis performed', timestamp: new Date(), type: 'symptom' },
    { id: 2, action: 'Differential diagnosis generated', timestamp: new Date(Date.now() - 3600000), type: 'diagnosis' },
    { id: 3, action: 'Risk assessment completed', timestamp: new Date(Date.now() - 7200000), type: 'risk' },
  ];

  const data = activities || defaultActivities;

  const getTypeColor = (type) => {
    switch(type) {
      case 'symptom': return 'bg-blue-500';
      case 'diagnosis': return 'bg-green-500';
      case 'risk': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="card">
      <h3 className="text-lg font-semibold mb-4">Recent Activities</h3>
      <div className="space-y-3">
        {data.map((activity, index) => (
          <motion.div
            key={activity.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-all"
          >
            <div className={`w-2 h-2 ${getTypeColor(activity.type)} rounded-full`} />
            <div className="flex-1">
              <p className="text-sm font-medium">{activity.action}</p>
              <p className="text-xs text-gray-500">
                {formatDistanceToNow(activity.timestamp, { addSuffix: true })}
              </p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default RecentActivities;