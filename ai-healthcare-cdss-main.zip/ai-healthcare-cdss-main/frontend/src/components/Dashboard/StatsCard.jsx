import React from 'react';
import { motion } from 'framer-motion';
import { FiTrendingUp, FiCheckCircle, FiClock, FiUsers } from 'react-icons/fi';

const StatsCard = ({ title, value, icon: Icon, color, change }) => {
  const colors = {
    blue: 'bg-blue-500',
    green: 'bg-green-500',
    orange: 'bg-orange-500',
    purple: 'bg-purple-500',
  };

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="card"
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-gray-500 dark:text-gray-400 text-sm">{title}</p>
          <h3 className="text-2xl font-bold mt-1">{value}</h3>
          {change && (
            <p className="text-xs text-green-500 mt-1 flex items-center">
              <FiTrendingUp className="mr-1" /> {change}
            </p>
          )}
        </div>
        <div className={`${colors[color]} p-3 rounded-full`}>
          <Icon className="text-white w-6 h-6" />
        </div>
      </div>
    </motion.div>
  );
};

export default StatsCard;