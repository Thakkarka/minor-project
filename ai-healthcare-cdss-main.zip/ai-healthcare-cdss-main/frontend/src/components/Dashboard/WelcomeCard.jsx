import React from 'react';
import { motion } from 'framer-motion';
import { useApp } from '../../context/AppContext';

const WelcomeCard = () => {
  const { patientId } = useApp();
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="card bg-gradient-to-r from-primary-600 to-primary-800 text-white"
    >
      <h1 className="text-3xl font-bold mb-2">Welcome to AI Healthcare CDSS</h1>
      <p className="text-primary-100 mb-4">
        Advanced Clinical Decision Support System powered by Artificial Intelligence
      </p>
      <div className="flex items-center space-x-4 text-sm">
        <div className="bg-white/20 rounded-lg px-3 py-1">
          Patient ID: {patientId}
        </div>
        <div className="bg-white/20 rounded-lg px-3 py-1">
          HIPAA Compliant
        </div>
      </div>
    </motion.div>
  );
};

export default WelcomeCard;