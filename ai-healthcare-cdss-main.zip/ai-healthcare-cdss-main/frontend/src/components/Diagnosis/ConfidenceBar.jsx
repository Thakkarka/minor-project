import React from 'react';
import { motion } from 'framer-motion';

const ConfidenceBar = ({ confidence }) => {
  const percentage = (confidence * 100).toFixed(0);
  
  const getColor = () => {
    if (confidence > 0.7) return 'bg-green-500';
    if (confidence > 0.4) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="w-full">
      <div className="flex justify-between text-sm mb-1">
        <span>Confidence Level</span>
        <span className="font-semibold">{percentage}%</span>
      </div>
      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className={`${getColor()} h-full rounded-full`}
        />
      </div>
    </div>
  );
};

export default ConfidenceBar;