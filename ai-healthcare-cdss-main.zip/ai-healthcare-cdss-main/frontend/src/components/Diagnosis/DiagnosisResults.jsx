import React from 'react';
import { motion } from 'framer-motion';
import { FiAward, FiClipboard, FiAlertCircle } from 'react-icons/fi';
import ConfidenceBar from './ConfidenceBar';
import DifferentialList from './DifferentialList';
import TreatmentSuggestions from './TreatmentSuggestions';

const DiagnosisResults = ({ diagnosis }) => {
  if (!diagnosis) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      {/* Primary Diagnosis */}
      <div className="card bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              <FiAward className="text-green-600 w-6 h-6" />
              <h3 className="text-lg font-semibold">Primary Diagnosis</h3>
            </div>
            <p className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
              {diagnosis.primary_diagnosis}
            </p>
            <ConfidenceBar confidence={diagnosis.confidence_score} />
          </div>
        </div>
      </div>

      {/* Differential Diagnoses */}
      <DifferentialList differentials={diagnosis.differential_diagnoses} />

      {/* Recommended Tests */}
      {diagnosis.recommended_tests && diagnosis.recommended_tests.length > 0 && (
        <div className="card">
          <h3 className="text-lg font-semibold mb-3 flex items-center">
            <FiClipboard className="mr-2" /> Recommended Tests
          </h3>
          <div className="space-y-2">
            {diagnosis.recommended_tests.map((test, index) => (
              <div key={index} className="flex items-center space-x-2 p-2 rounded-lg bg-gray-50 dark:bg-gray-800">
                <div className="w-2 h-2 bg-primary-500 rounded-full" />
                <span>{test}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Treatment Suggestions */}
      <TreatmentSuggestions treatments={diagnosis.treatment_suggestions} />

      {/* Clinical Reasoning */}
      {diagnosis.clinical_reasoning && (
        <div className="card">
          <h3 className="text-lg font-semibold mb-3 flex items-center">
            <FiAlertCircle className="mr-2" /> Clinical Reasoning
          </h3>
          <p className="text-gray-700 dark:text-gray-300">{diagnosis.clinical_reasoning}</p>
        </div>
      )}
    </motion.div>
  );
};

export default DiagnosisResults;