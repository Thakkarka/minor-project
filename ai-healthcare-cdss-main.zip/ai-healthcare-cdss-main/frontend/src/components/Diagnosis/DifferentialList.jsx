import React from 'react';
import { motion } from 'framer-motion';
import { FiActivity } from 'react-icons/fi';

const DifferentialList = ({ differentials }) => {
  if (!differentials || differentials.length === 0) return null;

  const getProbabilityColor = (probability) => {
    if (probability > 0.7) return 'bg-green-500';
    if (probability > 0.4) return 'bg-yellow-500';
    return 'bg-orange-500';
  };

  return (
    <div className="card">
      <h3 className="text-lg font-semibold mb-3 flex items-center">
        <FiActivity className="mr-2" /> Differential Diagnoses
      </h3>
      <div className="space-y-3">
        {differentials.map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-3 rounded-lg border dark:border-gray-700"
          >
            <div className="flex justify-between items-center mb-2">
              <span className="font-semibold">{item.condition}</span>
              <span className="text-sm font-medium">
                {(item.probability * 100).toFixed(0)}%
              </span>
            </div>
            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mb-2">
              <div
                className={`${getProbabilityColor(item.probability)} h-2 rounded-full transition-all duration-500`}
                style={{ width: `${item.probability * 100}%` }}
              />
            </div>
            {item.reasoning && (
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">{item.reasoning}</p>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default DifferentialList;