import React from 'react';
import { motion } from 'framer-motion';
import { FiCheckCircle, FiAlertTriangle } from 'react-icons/fi';

const TreatmentSuggestions = ({ treatments }) => {
  if (!treatments || treatments.length === 0) return null;

  return (
    <div className="card">
      <h3 className="text-lg font-semibold mb-3 flex items-center">
        <FiCheckCircle className="mr-2 text-green-500" /> Treatment Suggestions
      </h3>
      <div className="space-y-2">
        {treatments.map((treatment, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-start space-x-3 p-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-all"
          >
            <FiCheckCircle className="text-green-500 mt-0.5 flex-shrink-0" />
            <span>{treatment}</span>
          </motion.div>
        ))}
      </div>
      <div className="mt-4 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
        <div className="flex items-start space-x-2">
          <FiAlertTriangle className="text-yellow-600 mt-0.5 flex-shrink-0" />
          <p className="text-sm text-yellow-800 dark:text-yellow-200">
            ⚠️ These are AI-generated suggestions. Always consult with a healthcare provider before starting any treatment.
          </p>
        </div>
      </div>
    </div>
  );
};

export default TreatmentSuggestions;