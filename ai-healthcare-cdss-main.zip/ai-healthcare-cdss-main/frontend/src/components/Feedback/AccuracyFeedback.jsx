import React from 'react';
import { motion } from 'framer-motion';
import { FiThumbsUp, FiThumbsDown } from 'react-icons/fi';

const AccuracyFeedback = ({ onFeedback }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="flex items-center space-x-3 mt-2"
    >
      <span className="text-xs text-gray-500">Was this helpful?</span>
      <button
        onClick={() => onFeedback(true)}
        className="p-1 hover:bg-green-100 dark:hover:bg-green-900 rounded transition-all"
      >
        <FiThumbsUp className="w-4 h-4 text-green-600" />
      </button>
      <button
        onClick={() => onFeedback(false)}
        className="p-1 hover:bg-red-100 dark:hover:bg-red-900 rounded transition-all"
      >
        <FiThumbsDown className="w-4 h-4 text-red-600" />
      </button>
    </motion.div>
  );
};

export default AccuracyFeedback;