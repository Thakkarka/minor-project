import React, { useState } from 'react';
import { motion } from 'framer-motion';
import RatingStars from './RatingStars';
import Button from '../Common/Button';
import Input from '../Common/Input';
import toast from 'react-hot-toast';

const FeedbackForm = ({ onSubmit, diagnosisId }) => {
  const [accuracy, setAccuracy] = useState(0);
  const [helpfulness, setHelpfulness] = useState(0);
  const [comments, setComments] = useState('');
  const [suggestedDiagnosis, setSuggestedDiagnosis] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (accuracy === 0) {
      toast.error('Please rate the accuracy');
      return;
    }

    setSubmitting(true);
    await onSubmit({
      diagnosis_id: diagnosisId,
      accuracy_rating: accuracy,
      helpfulness_rating: helpfulness || accuracy,
      comments,
      suggested_diagnosis: suggestedDiagnosis,
    });
    setSubmitting(false);
  };

  return (
    <motion.form
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      onSubmit={handleSubmit}
      className="card"
    >
      <h3 className="text-lg font-semibold mb-4">Help Us Improve</h3>
      
      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">How accurate was this diagnosis?</label>
        <RatingStars value={accuracy} onChange={setAccuracy} />
      </div>

      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">How helpful were the suggestions?</label>
        <RatingStars value={helpfulness} onChange={setHelpfulness} />
      </div>

      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">Additional Comments</label>
        <textarea
          value={comments}
          onChange={(e) => setComments(e.target.value)}
          placeholder="Share your thoughts on how we can improve..."
          className="input-field resize-none"
          rows={3}
        />
      </div>

      <div className="mb-4">
        <Input
          label="Suggested Diagnosis (if different)"
          value={suggestedDiagnosis}
          onChange={(e) => setSuggestedDiagnosis(e.target.value)}
          placeholder="What diagnosis would you suggest?"
        />
      </div>

      <Button type="submit" loading={submitting} className="w-full">
        Submit Feedback
      </Button>
    </motion.form>
  );
};

export default FeedbackForm;