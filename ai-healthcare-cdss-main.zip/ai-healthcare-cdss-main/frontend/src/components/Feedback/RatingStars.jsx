import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FiStar } from 'react-icons/fi';

const RatingStars = ({ value, onChange, size = 'md' }) => {
  const [hover, setHover] = useState(0);

  const sizes = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8',
  };

  return (
    <div className="flex space-x-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <motion.button
          key={star}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          type="button"
          onClick={() => onChange(star)}
          onMouseEnter={() => setHover(star)}
          onMouseLeave={() => setHover(0)}
          className="focus:outline-none"
        >
          <FiStar
            className={`${sizes[size]} ${
              star <= (hover || value)
                ? 'fill-yellow-400 text-yellow-400'
                : 'text-gray-300 dark:text-gray-600'
            } transition-all duration-200`}
          />
        </motion.button>
      ))}
    </div>
  );
};

export default RatingStars;