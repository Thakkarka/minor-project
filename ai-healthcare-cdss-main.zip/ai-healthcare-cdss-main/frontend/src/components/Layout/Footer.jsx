import React from 'react';
import { FaHeart } from 'react-icons/fa';

const Footer = () => {
  return (
    <footer className="bg-white dark:bg-gray-900 border-t dark:border-gray-800 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="text-center">
          <p className="text-gray-600 dark:text-gray-400 text-sm">
            Built with <FaHeart className="inline text-red-500 mx-1" /> for healthcare professionals
          </p>
          <p className="text-gray-500 dark:text-gray-500 text-xs mt-2">
            ⚠️ This is an AI-assisted tool. Always consult with qualified healthcare providers.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;