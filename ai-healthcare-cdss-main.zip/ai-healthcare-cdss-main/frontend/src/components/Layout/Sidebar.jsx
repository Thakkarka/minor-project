import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  FiHome, FiActivity, FiBookOpen, FiMessageCircle, 
  FiClock, FiInfo, FiBarChart2, FiHeart, FiFileText 
} from 'react-icons/fi';

const Sidebar = ({ isOpen, onClose }) => {
  const location = useLocation();

  const menuItems = [
    { path: '/', name: 'Dashboard', icon: FiHome, color: 'text-primary-500' },
    { path: '/symptom-checker', name: 'Symptom Checker', icon: FiActivity, color: 'text-blue-500' },
    { path: '/diagnosis', name: 'Diagnosis', icon: FiFileText, color: 'text-green-500' },
    { path: '/risk-assessment', name: 'Risk Assessment', icon: FiBarChart2, color: 'text-orange-500' },
    { path: '/literature', name: 'Medical Literature', icon: FiBookOpen, color: 'text-purple-500' },
    { path: '/chat', name: 'AI Assistant', icon: FiMessageCircle, color: 'text-pink-500' },
    { path: '/history', name: 'History', icon: FiClock, color: 'text-gray-500' },
    { path: '/about', name: 'About', icon: FiInfo, color: 'text-indigo-500' },
  ];

  const isActive = (path) => location.pathname === path;

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40" onClick={onClose} />
      )}
      
      <motion.aside
        initial={{ x: -280 }}
        animate={{ x: isOpen ? 0 : -280 }}
        transition={{ type: 'spring', damping: 20 }}
        className="fixed left-0 top-0 h-full w-64 bg-white dark:bg-gray-900 shadow-2xl z-50 overflow-y-auto"
      >
        <div className="p-4 border-b dark:border-gray-700">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-gradient-to-r from-primary-600 to-primary-800 rounded-lg flex items-center justify-center">
              <FiHeart className="text-white w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-lg">AI Healthcare</h2>
              <p className="text-xs text-gray-500">Clinical Decision Support</p>
            </div>
          </div>
        </div>

        <nav className="p-4 space-y-2">
          {menuItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              onClick={onClose}
              className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                isActive(item.path)
                  ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-400'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              <item.icon className={`w-5 h-5 ${item.color}`} />
              <span className="flex-1">{item.name}</span>
              {isActive(item.path) && (
                <motion.div
                  layoutId="active-indicator"
                  className="w-1 h-8 bg-primary-500 rounded-full"
                />
              )}
            </Link>
          ))}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t dark:border-gray-700">
          <div className="text-xs text-center text-gray-500">
            <p>Version 1.0.0</p>
            <p>© 2024 AI Healthcare CDSS</p>
          </div>
        </div>
      </motion.aside>
    </>
  );
};

export default Sidebar;