import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FiBookOpen, FiExternalLink, FiCalendar, FiStar } from 'react-icons/fi';
import ReactMarkdown from 'react-markdown';

const ArticleCard = ({ article, index }) => {
  const [expanded, setExpanded] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="card hover:shadow-xl transition-all cursor-pointer"
      onClick={() => setExpanded(!expanded)}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <FiBookOpen className="text-primary-500" />
            <span className="text-xs text-gray-500">{article.source}</span>
            {article.year && (
              <span className="text-xs text-gray-500 flex items-center">
                <FiCalendar className="mr-1 w-3 h-3" /> {article.year}
              </span>
            )}
            {article.relevance_score && (
              <span className="text-xs text-gray-500 flex items-center">
                <FiStar className="mr-1 w-3 h-3 text-yellow-500" /> 
                {Math.round(article.relevance_score * 100)}% relevant
              </span>
            )}
          </div>
          <h3 className="font-semibold text-lg mb-2">{article.title}</h3>
          <p className="text-gray-600 dark:text-gray-400 text-sm line-clamp-2">
            {article.summary}
          </p>
        </div>
        <FiExternalLink className="text-gray-400 flex-shrink-0 ml-4" />
      </div>

      {expanded && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="mt-4 pt-4 border-t dark:border-gray-700"
        >
          <ReactMarkdown className="prose dark:prose-invert max-w-none text-sm">
            {article.detailed_info || article.summary}
          </ReactMarkdown>
          {article.references && article.references.length > 0 && (
            <div className="mt-3">
              <p className="text-xs font-semibold mb-1">References:</p>
              <ul className="text-xs text-gray-500 space-y-1">
                {article.references.map((ref, i) => (
                  <li key={i}>{ref}</li>
                ))}
              </ul>
            </div>
          )}
        </motion.div>
      )}
    </motion.div>
  );
};

export default ArticleCard;