import React, { useState } from 'react';
import { FiCopy, FiCheck } from 'react-icons/fi';
import toast from 'react-hot-toast';

const CitationViewer = ({ article }) => {
  const [copied, setCopied] = useState(false);

  const generateCitation = () => {
    return `${article.authors || 'Authors'}. (${article.year || '2024'}). ${article.title}. ${article.journal || 'Medical Journal'}.`;
  };

  const copyCitation = () => {
    const citation = generateCitation();
    navigator.clipboard.writeText(citation);
    setCopied(true);
    toast.success('Citation copied to clipboard');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="mt-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <p className="text-xs font-semibold mb-1">Citation (APA):</p>
          <p className="text-xs text-gray-600 dark:text-gray-400">{generateCitation()}</p>
        </div>
        <button
          onClick={copyCitation}
          className="ml-2 p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-all"
        >
          {copied ? <FiCheck className="text-green-500" /> : <FiCopy />}
        </button>
      </div>
    </div>
  );
};

export default CitationViewer;