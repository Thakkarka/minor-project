import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FiSearch, FiFilter } from 'react-icons/fi';
import toast from 'react-hot-toast';

const LiteratureSearch = ({ onSearch, loading }) => {
  const [query, setQuery] = useState('');
  const [filters, setFilters] = useState({
    year: 'all',
    type: 'all',
  });
  const [showFilters, setShowFilters] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!query.trim()) {
      toast.error('Please enter a search query');
      return;
    }
    onSearch(query, filters);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="card"
    >
      <form onSubmit={handleSubmit}>
        <div className="relative">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search medical literature (e.g., 'hypertension treatment guidelines')..."
            className="input-field pr-24"
            disabled={loading}
          />
          <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex space-x-1">
            <button
              type="button"
              onClick={() => setShowFilters(!showFilters)}
              className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-all"
            >
              <FiFilter className="w-4 h-4" />
            </button>
            <button
              type="submit"
              disabled={loading || !query.trim()}
              className="btn-primary py-1 px-3 text-sm disabled:opacity-50"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <FiSearch />
              )}
            </button>
          </div>
        </div>

        {showFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="mt-4 grid grid-cols-2 gap-4"
          >
            <div>
              <label className="block text-sm font-medium mb-1">Year Range</label>
              <select
                value={filters.year}
                onChange={(e) => setFilters({ ...filters, year: e.target.value })}
                className="input-field"
              >
                <option value="all">All Years</option>
                <option value="2024">2024</option>
                <option value="2023">2023</option>
                <option value="2022">2022</option>
                <option value="2021">2021</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Article Type</label>
              <select
                value={filters.type}
                onChange={(e) => setFilters({ ...filters, type: e.target.value })}
                className="input-field"
              >
                <option value="all">All Types</option>
                <option value="guideline">Guidelines</option>
                <option value="review">Reviews</option>
                <option value="research">Research Articles</option>
                <option value="meta">Meta-Analyses</option>
              </select>
            </div>
          </motion.div>
        )}
      </form>
    </motion.div>
  );
};

export default LiteratureSearch;