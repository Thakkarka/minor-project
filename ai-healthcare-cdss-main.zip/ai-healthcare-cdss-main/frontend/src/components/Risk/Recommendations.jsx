import React from 'react';
import { motion } from 'framer-motion';
import { FiCheckCircle, FiAlertTriangle, FiShield } from 'react-icons/fi';

const Recommendations = ({ actions, riskLevel }) => {
  if (!actions || actions.length === 0) return null;

  const getIcon = () => {
    switch(riskLevel?.toLowerCase()) {
      case 'low': return <FiShield className="text-green-500" />;
      case 'moderate': return <FiAlertTriangle className="text-yellow-500" />;
      case 'high': return <FiAlertTriangle className="text-orange-500" />;
      case 'critical': return <FiAlertTriangle className="text-red-500" />;
      default: return <FiCheckCircle />;
    }
  };

  return (
    <div className="card">
      <h3 className="text-lg font-semibold mb-3 flex items-center">
        {getIcon()}
        <span className="ml-2">Recommended Actions</span>
      </h3>
      <div className="space-y-2">
        {actions.map((action, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-start space-x-3 p-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-all"
          >
            <FiCheckCircle className="text-primary-500 mt-0.5 flex-shrink-0" />
            <span>{action}</span>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default Recommendations;