import React from 'react';
import { motion } from 'framer-motion';
import { FiAlertCircle } from 'react-icons/fi';

const RiskFactors = ({ factors }) => {
  if (!factors || factors.length === 0) return null;

  return (
    <div className="card">
      <h3 className="text-lg font-semibold mb-3 flex items-center">
        <FiAlertCircle className="mr-2 text-orange-500" /> Contributing Risk Factors
      </h3>
      <div className="space-y-2">
        {factors.map((factor, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-center space-x-2 p-2 rounded-lg bg-red-50 dark:bg-red-900/20"
          >
            <div className="w-2 h-2 bg-red-500 rounded-full" />
            <span className="text-sm">{factor}</span>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default RiskFactors;