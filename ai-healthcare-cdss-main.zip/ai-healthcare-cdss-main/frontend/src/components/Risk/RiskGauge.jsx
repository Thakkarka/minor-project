import React from 'react';
import { motion } from 'framer-motion';

const RiskGauge = ({ score }) => {
  const percentage = Math.min(Math.max(score, 0), 100);
  
  const getColor = () => {
    if (percentage < 20) return '#10b981';
    if (percentage < 50) return '#f59e0b';
    if (percentage < 75) return '#ef4444';
    return '#7f1d1d';
  };

  const radius = 80;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (percentage / 100) * circumference;

  return (
    <div className="relative inline-flex items-center justify-center">
      <svg width="200" height="200" viewBox="0 0 200 200">
        {/* Background circle */}
        <circle
          cx="100"
          cy="100"
          r={radius}
          fill="none"
          stroke="#e5e7eb"
          strokeWidth="12"
        />
        {/* Progress circle */}
        <motion.circle
          cx="100"
          cy="100"
          r={radius}
          fill="none"
          stroke={getColor()}
          strokeWidth="12"
          strokeLinecap="round"
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1, ease: "easeOut" }}
          style={{
            strokeDasharray: circumference,
            transform: "rotate(-90deg)",
            transformOrigin: "50% 50%",
          }}
        />
        {/* Center text */}
        <text
          x="100"
          y="100"
          textAnchor="middle"
          dominantBaseline="middle"
          className="text-3xl font-bold"
          fill="currentColor"
        >
          {percentage}
        </text>
        <text
          x="100"
          y="130"
          textAnchor="middle"
          className="text-xs fill-current text-gray-500"
        >
          Risk Score
        </text>
      </svg>
    </div>
  );
};

export default RiskGauge;