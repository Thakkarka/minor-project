import React from 'react';
import { motion } from 'framer-motion';
import RiskGauge from './RiskGauge';
import RiskFactors from './RiskFactors';
import Recommendations from './Recommendations';

const RiskScoreCard = ({ riskData }) => {
  if (!riskData) return null;

  const getRiskColor = (level) => {
    switch(level?.toLowerCase()) {
      case 'low': return 'text-green-600 bg-green-100';
      case 'moderate': return 'text-yellow-600 bg-yellow-100';
      case 'high': return 'text-orange-600 bg-orange-100';
      case 'critical': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="space-y-4"
    >
      {/* Risk Score Gauge */}
      <div className="card text-center">
        <h3 className="text-lg font-semibold mb-4">Risk Assessment Score</h3>
        <RiskGauge score={riskData.risk_score} />
        <div className="mt-4">
          <span className={`inline-flex px-4 py-2 rounded-full text-sm font-semibold ${getRiskColor(riskData.risk_level)}`}>
            {riskData.risk_level} Risk
          </span>
        </div>
        <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
          30-Day Mortality Risk: {riskData.mortality_risk_30d}%
        </p>
      </div>

      {/* Risk Factors */}
      <RiskFactors factors={riskData.risk_factors} />

      {/* Recommendations */}
      <Recommendations actions={riskData.recommended_actions} riskLevel={riskData.risk_level} />
    </motion.div>
  );
};

export default RiskScoreCard;