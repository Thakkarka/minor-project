import React, { useState } from 'react';
import { motion } from 'framer-motion';

const bodyParts = [
  { id: 'head', name: 'Head', x: 50, y: 15, symptoms: ['headache', 'dizziness', 'vision problems'] },
  { id: 'chest', name: 'Chest', x: 50, y: 35, symptoms: ['chest pain', 'shortness of breath', 'palpitations'] },
  { id: 'abdomen', name: 'Abdomen', x: 50, y: 50, symptoms: ['abdominal pain', 'nausea', 'bloating'] },
  { id: 'arms', name: 'Arms', x: 25, y: 40, symptoms: ['arm pain', 'weakness', 'numbness'] },
  { id: 'legs', name: 'Legs', x: 50, y: 70, symptoms: ['leg pain', 'swelling', 'weakness'] },
  { id: 'back', name: 'Back', x: 70, y: 45, symptoms: ['back pain', 'stiffness'] },
];

const BodyMap = ({ onSelect }) => {
  const [selected, setSelected] = useState(null);

  const handleClick = (part) => {
    setSelected(part);
    onSelect(part.symptoms);
  };

  return (
    <div className="card">
      <h3 className="text-lg font-semibold mb-4">Interactive Body Map</h3>
      <div className="relative min-h-[400px] bg-gray-50 dark:bg-gray-800 rounded-lg overflow-hidden">
        <svg viewBox="0 0 100 100" className="w-full h-full">
          {/* Body outline */}
          <path
            d="M50 5 C30 5, 20 20, 20 40 C20 60, 30 80, 40 95 L60 95 C70 80, 80 60, 80 40 C80 20, 70 5, 50 5Z"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            className="text-gray-400"
          />
          
          {/* Clickable areas */}
          {bodyParts.map((part) => (
            <g key={part.id}>
              <circle
                cx={part.x}
                cy={part.y}
                r="5"
                fill={selected?.id === part.id ? '#4f46e5' : '#6366f1'}
                className="cursor-pointer hover:fill-primary-600 transition-all"
                onClick={() => handleClick(part)}
              />
              <text
                x={part.x}
                y={part.y - 8}
                textAnchor="middle"
                fontSize="3"
                className="text-xs fill-current"
              >
                {part.name}
              </text>
            </g>
          ))}
        </svg>
        
        {selected && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute bottom-4 left-4 right-4 bg-white dark:bg-gray-900 rounded-lg p-3 shadow-lg"
          >
            <p className="font-semibold text-sm">{selected.name}</p>
            <div className="flex flex-wrap gap-1 mt-1">
              {selected.symptoms.map((symptom, i) => (
                <span key={i} className="text-xs px-2 py-1 bg-primary-100 dark:bg-primary-900 text-primary-700 rounded-full">
                  {symptom}
                </span>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default BodyMap;