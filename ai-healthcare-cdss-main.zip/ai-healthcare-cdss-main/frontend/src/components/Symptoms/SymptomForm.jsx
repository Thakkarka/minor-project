import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Select from 'react-select';
import { FiPlus, FiX } from 'react-icons/fi';

const commonSymptoms = [
  { value: 'headache', label: '🤕 Headache' },
  { value: 'fever', label: '🌡️ Fever' },
  { value: 'cough', label: '😷 Cough' },
  { value: 'fatigue', label: '😴 Fatigue' },
  { value: 'nausea', label: '🤢 Nausea' },
  { value: 'vomiting', label: '🤮 Vomiting' },
  { value: 'diarrhea', label: '💩 Diarrhea' },
  { value: 'chest pain', label: '💔 Chest Pain' },
  { value: 'shortness of breath', label: '😤 Shortness of Breath' },
  { value: 'dizziness', label: '🌀 Dizziness' },
  { value: 'rash', label: '🔴 Rash' },
  { value: 'joint pain', label: '🦵 Joint Pain' },
];

const SymptomForm = ({ onSymptomsChange }) => {
  const [selectedSymptoms, setSelectedSymptoms] = useState([]);
  const [customSymptom, setCustomSymptom] = useState('');

  const handleSelectChange = (selected) => {
    setSelectedSymptoms(selected);
    onSymptomsChange(selected.map(s => s.value));
  };

  const addCustomSymptom = () => {
    if (customSymptom.trim()) {
      const newSymptom = { value: customSymptom, label: customSymptom };
      setSelectedSymptoms([...selectedSymptoms, newSymptom]);
      onSymptomsChange([...selectedSymptoms.map(s => s.value), customSymptom]);
      setCustomSymptom('');
    }
  };

  const removeSymptom = (symptomToRemove) => {
    const updated = selectedSymptoms.filter(s => s.value !== symptomToRemove.value);
    setSelectedSymptoms(updated);
    onSymptomsChange(updated.map(s => s.value));
  };

  return (
    <div className="card">
      <h3 className="text-lg font-semibold mb-4">Select or Add Symptoms</h3>
      
      <Select
        isMulti
        options={commonSymptoms}
        value={selectedSymptoms}
        onChange={handleSelectChange}
        className="mb-4"
        classNamePrefix="react-select"
        placeholder="Search or select symptoms..."
        styles={{
          control: (base) => ({
            ...base,
            borderRadius: '0.5rem',
            borderColor: '#e5e7eb',
          }),
        }}
      />
      
      <div className="flex space-x-2">
        <input
          type="text"
          value={customSymptom}
          onChange={(e) => setCustomSymptom(e.target.value)}
          placeholder="Or type a custom symptom"
          className="input-field flex-1"
          onKeyPress={(e) => e.key === 'Enter' && addCustomSymptom()}
        />
        <button
          onClick={addCustomSymptom}
          className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-all"
        >
          <FiPlus />
        </button>
      </div>
      
      {selectedSymptoms.length > 0 && (
        <div className="mt-4">
          <p className="text-sm text-gray-600 mb-2">Selected Symptoms:</p>
          <div className="flex flex-wrap gap-2">
            <AnimatePresence>
              {selectedSymptoms.map((symptom) => (
                <motion.span
                  key={symptom.value}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                  className="inline-flex items-center space-x-1 px-3 py-1 bg-primary-100 dark:bg-primary-900 text-primary-700 dark:text-primary-300 rounded-full text-sm"
                >
                  <span>{symptom.label}</span>
                  <button
                    onClick={() => removeSymptom(symptom)}
                    className="hover:text-red-500 transition-colors"
                  >
                    <FiX className="w-3 h-3" />
                  </button>
                </motion.span>
              ))}
            </AnimatePresence>
          </div>
        </div>
      )}
    </div>
  );
};

export default SymptomForm;