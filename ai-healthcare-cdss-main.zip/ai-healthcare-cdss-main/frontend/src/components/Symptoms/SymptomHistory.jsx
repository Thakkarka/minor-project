import React from 'react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { FiClock, FiActivity } from 'react-icons/fi';

const SymptomHistory = ({ history }) => {
  const sampleHistory = [
    { id: 1, date: new Date(), symptoms: ['headache', 'fatigue'], severity: 65 },
    { id: 2, date: new Date(Date.now() - 86400000), symptoms: ['cough', 'fever'], severity: 45 },
  ];

  const data = history || sampleHistory;

  const getSeverityColor = (severity) => {
    if (severity < 30) return 'bg-green-500';
    if (severity < 70) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="card">
      <h3 className="text-lg font-semibold mb-4 flex items-center">
        <FiClock className="mr-2" /> Symptom History
      </h3>
      <div className="space-y-3">
        {data.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-3 rounded-lg border dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 transition-all"
          >
            <div className="flex justify-between items-start mb-2">
              <div>
                <p className="text-sm text-gray-500">
                  {format(item.date, 'MMM dd, yyyy h:mm a')}
                </p>
                <div className="flex flex-wrap gap-1 mt-1">
                  {item.symptoms.map((symptom, i) => (
                    <span key={i} className="text-xs px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded-full">
                      {symptom}
                    </span>
                  ))}
                </div>
              </div>
              <div className="text-right">
                <div className={`w-12 h-12 rounded-full ${getSeverityColor(item.severity)} flex items-center justify-center text-white font-bold`}>
                  {item.severity}
                </div>
                <p className="text-xs text-gray-500 mt-1">Severity</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default SymptomHistory;