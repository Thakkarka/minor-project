import React, { useState } from 'react';
import { motion } from 'framer-motion';
import TextareaAutosize from 'react-textarea-autosize';
import { FiSend, FiMic } from 'react-icons/fi';
import toast from 'react-hot-toast';

const SymptomInput = ({ onSubmit, loading }) => {
  const [symptoms, setSymptoms] = useState('');
  const [isRecording, setIsRecording] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!symptoms.trim()) {
      toast.error('Please enter your symptoms');
      return;
    }
    onSubmit(symptoms);
  };

  const handleVoiceInput = () => {
    if (!('webkitSpeechRecognition' in window)) {
      toast.error('Voice input not supported in this browser');
      return;
    }
    
    const recognition = new window.webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    
    recognition.onstart = () => {
      setIsRecording(true);
    };
    
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setSymptoms(transcript);
      setIsRecording(false);
    };
    
    recognition.onerror = () => {
      setIsRecording(false);
      toast.error('Voice recognition failed');
    };
    
    recognition.start();
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="card"
    >
      <h2 className="text-xl font-semibold mb-4">Describe Your Symptoms</h2>
      <form onSubmit={handleSubmit}>
        <div className="relative">
          <TextareaAutosize
            minRows={4}
            maxRows={8}
            value={symptoms}
            onChange={(e) => setSymptoms(e.target.value)}
            placeholder="Example: I've had a severe headache for 3 days, accompanied by nausea and sensitivity to light..."
            className="input-field resize-none"
            disabled={loading}
          />
          <div className="absolute bottom-3 right-3 flex space-x-2">
            <button
              type="button"
              onClick={handleVoiceInput}
              className={`p-2 rounded-full transition-all ${isRecording ? 'bg-red-500 text-white animate-pulse' : 'bg-gray-100 hover:bg-gray-200'}`}
            >
              <FiMic className="w-4 h-4" />
            </button>
          </div>
        </div>
        <div className="mt-4 flex justify-end">
          <button
            type="submit"
            disabled={loading || !symptoms.trim()}
            className="btn-primary flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <span>Analyze Symptoms</span>
                <FiSend />
              </>
            )}
          </button>
        </div>
      </form>
    </motion.div>
  );
};

export default SymptomInput;