import React, { createContext, useState, useContext } from 'react';

const AppContext = createContext();

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};

export const AppProvider = ({ children }) => {
  const [patientId, setPatientId] = useState(() => {
    return localStorage.getItem('patientId') || `PAT_${Date.now()}`;
  });
  const [currentSymptoms, setCurrentSymptoms] = useState(null);
  const [currentDiagnosis, setCurrentDiagnosis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const savePatientId = (id) => {
    setPatientId(id);
    localStorage.setItem('patientId', id);
  };

  const value = {
    patientId,
    setPatientId: savePatientId,
    currentSymptoms,
    setCurrentSymptoms,
    currentDiagnosis,
    setCurrentDiagnosis,
    loading,
    setLoading,
    error,
    setError,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};