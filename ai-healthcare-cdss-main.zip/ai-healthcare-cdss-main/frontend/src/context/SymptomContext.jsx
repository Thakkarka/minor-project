import React, { createContext, useState, useContext } from 'react';

const SymptomContext = createContext();

export const useSymptoms = () => useContext(SymptomContext);

export const SymptomProvider = ({ children }) => {
  const [symptoms, setSymptoms] = useState([]);
  const [selectedSymptoms, setSelectedSymptoms] = useState([]);
  const [symptomHistory, setSymptomHistory] = useState([]);

  const addSymptom = (symptom) => {
    setSymptoms([...symptoms, { ...symptom, id: Date.now(), timestamp: new Date() }]);
  };

  const removeSymptom = (id) => {
    setSymptoms(symptoms.filter(s => s.id !== id));
  };

  const clearSymptoms = () => {
    setSymptoms([]);
    setSelectedSymptoms([]);
  };

  return (
    <SymptomContext.Provider value={{
      symptoms,
      selectedSymptoms,
      symptomHistory,
      addSymptom,
      removeSymptom,
      clearSymptoms,
      setSelectedSymptoms
    }}>
      {children}
    </SymptomContext.Provider>
  );
};