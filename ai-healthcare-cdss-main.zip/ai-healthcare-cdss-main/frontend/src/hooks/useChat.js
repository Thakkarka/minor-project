import { useState, useCallback } from 'react';
import { chatService } from '../services/chatService';

export const useChat = () => {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [sessionId, setSessionId] = useState(null);
  const [error, setError] = useState(null);

  const sendMessage = useCallback(async (message, patientContext) => {
    setLoading(true);
    setError(null);
    try {
      const result = await chatService.sendMessage({
        message,
        patient_context: patientContext,
        session_id: sessionId,
      });
      
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: result.response,
        timestamp: new Date(),
      }]);
      
      if (result.session_id) {
        setSessionId(result.session_id);
      }
      
      return result;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [sessionId]);

  const addUserMessage = useCallback((content) => {
    setMessages(prev => [...prev, {
      role: 'user',
      content,
      timestamp: new Date(),
    }]);
  }, []);

  const clearChat = useCallback(async () => {
    if (sessionId) {
      await chatService.clearSession(sessionId);
    }
    setMessages([]);
    setSessionId(null);
    setError(null);
  }, [sessionId]);

  return { messages, loading, sessionId, error, sendMessage, addUserMessage, clearChat };
};