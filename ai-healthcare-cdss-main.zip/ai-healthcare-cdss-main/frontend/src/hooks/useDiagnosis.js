import { useState, useCallback } from 'react';
import { diagnosisService } from '../services/diagnosisService';

export const useDiagnosis = () => {
  const [diagnosis, setDiagnosis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const getDiagnosis = useCallback(async (diagnosisData) => {
    setLoading(true);
    setError(null);
    try {
      const result = await diagnosisService.getDifferentialDiagnosis(diagnosisData);
      setDiagnosis(result);
      return result;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const clearDiagnosis = useCallback(() => {
    setDiagnosis(null);
    setError(null);
  }, []);

  return { diagnosis, loading, error, getDiagnosis, clearDiagnosis };
};