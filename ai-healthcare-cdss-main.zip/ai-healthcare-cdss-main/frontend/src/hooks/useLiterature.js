import { useState, useCallback } from 'react';
import { literatureService } from '../services/literatureService';

export const useLiterature = () => {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const searchLiterature = useCallback(async (query) => {
    setLoading(true);
    setError(null);
    try {
      const result = await literatureService.searchLiterature(query);
      setResults(result.results || []);
      return result;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const clearResults = useCallback(() => {
    setResults([]);
    setError(null);
  }, []);

  return { results, loading, error, searchLiterature, clearResults };
};