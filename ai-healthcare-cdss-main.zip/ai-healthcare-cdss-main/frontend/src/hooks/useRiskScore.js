import { useState, useCallback } from 'react';
import { riskService } from '../services/riskService';

export const useRiskScore = () => {
  const [riskData, setRiskData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const calculateRisk = useCallback(async (riskData) => {
    setLoading(true);
    setError(null);
    try {
      const result = await riskService.calculateRisk(riskData);
      setRiskData(result);
      return result;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const clearRisk = useCallback(() => {
    setRiskData(null);
    setError(null);
  }, []);

  return { riskData, loading, error, calculateRisk, clearRisk };
};