import { useState, useCallback } from 'react';
import { symptomService } from '../services/symptomService';

export const useSymptoms = () => {
  const [symptoms, setSymptoms] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const analyzeSymptoms = useCallback(async (symptomData) => {
    setLoading(true);
    setError(null);
    try {
      const result = await symptomService.analyzeSymptoms(symptomData);
      setSymptoms(result);
      return result;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const clearSymptoms = useCallback(() => {
    setSymptoms([]);
    setError(null);
  }, []);

  return { symptoms, loading, error, analyzeSymptoms, clearSymptoms };
};