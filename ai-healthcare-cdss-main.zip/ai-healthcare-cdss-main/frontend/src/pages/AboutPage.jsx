import React from 'react';
import { motion } from 'framer-motion';
import { FiShield, FiCpu, FiBookOpen, FiHeart } from 'react-icons/fi';

const AboutPage = () => {
  const features = [
    {
      icon: FiCpu,
      title: 'AI-Powered Analysis',
      description: 'Advanced AI models analyze symptoms and provide evidence-based recommendations',
    },
    {
      icon: FiShield,
      title: 'HIPAA Compliant',
      description: 'Designed with healthcare compliance and patient privacy in mind',
    },
    {
      icon: FiBookOpen,
      title: 'Medical Literature',
      description: 'Access to latest medical research and clinical guidelines',
    },
    {
      icon: FiHeart,
      title: 'Risk Assessment',
      description: 'Comprehensive risk scoring and mortality prediction',
    },
  ];

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="card text-center"
      >
        <h1 className="text-3xl font-bold mb-4">About AI Healthcare CDSS</h1>
        <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
          An advanced Clinical Decision Support System powered by artificial intelligence,
          designed to assist healthcare professionals in making accurate, evidence-based decisions.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {features.map((feature, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="card text-center"
          >
            <feature.icon className="w-12 h-12 text-primary-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
            <p className="text-gray-600 dark:text-gray-400">{feature.description}</p>
          </motion.div>
        ))}
      </div>

      <div className="card">
        <h2 className="text-xl font-semibold mb-4">Technology Stack</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <p className="font-semibold">Frontend</p>
            <p className="text-sm text-gray-600">React, Tailwind CSS</p>
          </div>
          <div>
            <p className="font-semibold">Backend</p>
            <p className="text-sm text-gray-600">FastAPI, Python</p>
          </div>
          <div>
            <p className="font-semibold">AI/ML</p>
            <p className="text-sm text-gray-600">Gemini API, RAG</p>
          </div>
          <div>
            <p className="font-semibold">Database</p>
            <p className="text-sm text-gray-600">SQLite, Redis</p>
          </div>
        </div>
      </div>

      <div className="card bg-yellow-50 dark:bg-yellow-900/20">
        <h2 className="text-lg font-semibold mb-2">⚠️ Disclaimer</h2>
        <p className="text-sm text-gray-700 dark:text-gray-300">
          This system is an AI-assisted tool for clinical decision support. All recommendations
          should be reviewed by qualified healthcare professionals. The system does not replace
          professional medical judgment. Always verify information with current medical guidelines.
        </p>
      </div>
    </div>
  );
};

export default AboutPage;