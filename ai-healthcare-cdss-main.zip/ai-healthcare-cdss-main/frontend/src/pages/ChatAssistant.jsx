import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useApp } from '../context/AppContext';
import ChatInterface from '../components/Chat/ChatInterface';
import { chatService } from '../services/chatService';
import toast from 'react-hot-toast';

const ChatAssistant = () => {
  const { patientId } = useApp();
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: 'Hello! I\'m your AI medical assistant. How can I help you today?',
      timestamp: new Date(),
    },
  ]);
  const [loading, setLoading] = useState(false);
  const [sessionId, setSessionId] = useState(null);

  useEffect(() => {
    // Create a new session
    setSessionId(`session_${Date.now()}`);
  }, []);

  const handleSendMessage = async (message) => {
    // Add user message
    const userMessage = {
      role: 'user',
      content: message,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMessage]);
    setLoading(true);

    try {
      const response = await chatService.sendMessage({
        message,
        patient_context: { patient_id: patientId },
        session_id: sessionId,
      });
      
      const assistantMessage = {
        role: 'assistant',
        content: response.response,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, assistantMessage]);
      
      if (response.session_id) {
        setSessionId(response.session_id);
      }
    } catch (error) {
      toast.error('Failed to get response');
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'I apologize, but I encountered an error. Please try again.',
        timestamp: new Date(),
      }]);
    } finally {
      setLoading(false);
    }
  };

  const handleClear = async () => {
    if (sessionId) {
      await chatService.clearSession(sessionId);
    }
    setMessages([
      {
        role: 'assistant',
        content: 'Chat cleared. How can I help you?',
        timestamp: new Date(),
      },
    ]);
    setSessionId(`session_${Date.now()}`);
    toast.success('Chat cleared');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <h1 className="text-2xl font-bold mb-4">AI Medical Assistant</h1>
      <p className="text-gray-600 dark:text-gray-400 mb-6">
        Get instant answers to medical questions, treatment guidelines, and drug information
      </p>
      
      <ChatInterface
        onSendMessage={handleSendMessage}
        messages={messages}
        loading={loading}
        onClear={handleClear}
        sessionId={sessionId}
      />
    </motion.div>
  );
};

export default ChatAssistant;