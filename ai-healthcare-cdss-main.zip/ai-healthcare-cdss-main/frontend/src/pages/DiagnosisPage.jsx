import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useApp } from '../context/AppContext';
import DiagnosisResults from '../components/Diagnosis/DiagnosisResults';
import FeedbackForm from '../components/Feedback/FeedbackForm';
import { diagnosisService } from '../services/diagnosisService';
import { feedbackService } from '../services/feedbackService';
import LoadingSpinner from '../components/Common/LoadingSpinner';
import toast from 'react-hot-toast';

const DiagnosisPage = () => {
  const { currentSymptoms, patientId, loading, setLoading, setCurrentDiagnosis, currentDiagnosis } = useApp();
  const [showFeedback, setShowFeedback] = useState(false);

  useEffect(() => {
    if (currentSymptoms && !currentDiagnosis) {
      generateDiagnosis();
    }
  }, [currentSymptoms]);

  const generateDiagnosis = async () => {
    setLoading(true);
    try {
      const diagnosis = await diagnosisService.getDifferentialDiagnosis({
        patient_id: patientId,
        symptoms: currentSymptoms.symptoms_structured?.map(s => s.symptom) || [],
        patient_age: null,
      });
      setCurrentDiagnosis(diagnosis);
      toast.success('Diagnosis generated successfully');
    } catch (error) {
      toast.error('Failed to generate diagnosis');
    } finally {
      setLoading(false);
    }
  };

  const handleFeedback = async (feedbackData) => {
    try {
      await feedbackService.submitFeedback({
        ...feedbackData,
        patient_id: patientId,
      });
      toast.success('Thank you for your feedback!');
      setShowFeedback(false);
    } catch (error) {
      toast.error('Failed to submit feedback');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-96">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (!currentSymptoms) {
    return (
      <div className="card text-center py-12">
        <p className="text-gray-500">No symptoms analyzed yet. Please go to Symptom Checker first.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-2xl font-bold mb-4">Diagnosis Results</h1>
        <DiagnosisResults diagnosis={currentDiagnosis} />
        
        <div className="mt-6 flex justify-between items-center">
          <button
            onClick={() => setShowFeedback(!showFeedback)}
            className="text-sm text-gray-500 hover:text-gray-700"
          >
            {showFeedback ? 'Hide Feedback' : 'Give Feedback'}
          </button>
          <button
            onClick={generateDiagnosis}
            className="btn-secondary text-sm"
          >
            Regenerate Diagnosis
          </button>
        </div>

        {showFeedback && currentDiagnosis && (
          <div className="mt-4">
            <FeedbackForm
              onSubmit={handleFeedback}
              diagnosisId={currentDiagnosis.id || 'temp_id'}
            />
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default DiagnosisPage;