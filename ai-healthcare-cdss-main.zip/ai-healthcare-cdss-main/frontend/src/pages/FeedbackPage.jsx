import React, { useState } from 'react';
import { motion } from 'framer-motion';
import FeedbackForm from '../components/Feedback/FeedbackForm';
import { feedbackService } from '../services/feedbackService';
import { useApp } from '../context/AppContext';
import toast from 'react-hot-toast';

const FeedbackPage = () => {
  const { patientId } = useApp();
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (feedbackData) => {
    try {
      await feedbackService.submitFeedback({
        ...feedbackData,
        patient_id: patientId,
      });
      setSubmitted(true);
      toast.success('Thank you for your valuable feedback!');
    } catch (error) {
      toast.error('Failed to submit feedback');
    }
  };

  if (submitted) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="card text-center py-12"
      >
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h2 className="text-2xl font-bold mb-2">Thank You!</h2>
        <p className="text-gray-600 dark:text-gray-400">
          Your feedback helps us improve the system for everyone.
        </p>
      </motion.div>
    );
  }

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-2xl font-bold mb-4">Feedback</h1>
        <p className="text-gray-600 dark:text-gray-400 mb-6">
          Help us improve the AI Healthcare CDSS by sharing your experience
        </p>
        
        <div className="max-w-2xl mx-auto">
          <FeedbackForm onSubmit={handleSubmit} diagnosisId="general_feedback" />
        </div>
      </motion.div>
    </div>
  );
};

export default FeedbackPage;