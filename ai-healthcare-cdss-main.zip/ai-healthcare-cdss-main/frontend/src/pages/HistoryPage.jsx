import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { FiClock, FiActivity, FiChevronRight } from 'react-icons/fi';
import { useApp } from '../context/AppContext';
import { symptomService } from '../services/symptomService';
import LoadingSpinner from '../components/Common/LoadingSpinner';

const HistoryPage = () => {
  const { patientId } = useApp();
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    try {
      const data = await symptomService.getSymptomHistory(patientId);
      setHistory(data.history || []);
    } catch (error) {
      console.error('Failed to load history:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-96">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-2xl font-bold mb-4">Patient History</h1>
        
        {history.length === 0 ? (
          <div className="card text-center py-12">
            <p className="text-gray-500">No history found. Start by analyzing symptoms.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {history.map((item, index) => (
              <motion.div
                key={item.id || index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="card hover:shadow-xl transition-all cursor-pointer"
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <FiClock className="text-gray-400" />
                      <span className="text-sm text-gray-500">
                        {format(new Date(item.created_at), 'MMM dd, yyyy h:mm a')}
                      </span>
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        item.severity_score > 70 ? 'bg-red-100 text-red-700' :
                        item.severity_score > 40 ? 'bg-yellow-100 text-yellow-700' :
                        'bg-green-100 text-green-700'
                      }`}>
                        Severity: {item.severity_score}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                      {item.symptoms_raw?.substring(0, 200)}...
                    </p>
                    <div className="flex flex-wrap gap-1">
                      {item.symptoms_structured?.map((s, i) => (
                        <span key={i} className="text-xs px-2 py-1 bg-gray-100 dark:bg-gray-800 rounded-full">
                          {s.symptom}
                        </span>
                      ))}
                    </div>
                  </div>
                  <FiChevronRight className="text-gray-400" />
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default HistoryPage;