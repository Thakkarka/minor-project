import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { FiActivity, FiBookOpen, FiMessageCircle, FiBarChart2 } from 'react-icons/fi';
import WelcomeCard from '../components/Dashboard/WelcomeCard';
import StatsCard from '../components/Dashboard/StatsCard';
import RecentActivities from '../components/Dashboard/RecentActivities';

const HomePage = () => {
  const features = [
    { title: 'Symptom Checker', icon: FiActivity, path: '/symptom-checker', color: 'blue', description: 'Input and analyze patient symptoms' },
    { title: 'Risk Assessment', icon: FiBarChart2, path: '/risk-assessment', color: 'orange', description: 'Calculate and interpret risk scores' },
    { title: 'Literature Search', icon: FiBookOpen, path: '/literature', color: 'purple', description: 'Search medical literature' },
    { title: 'AI Assistant', icon: FiMessageCircle, path: '/chat', color: 'green', description: 'Get AI-powered medical guidance' },
  ];

  return (
    <div className="space-y-6">
      <WelcomeCard />
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard title="Total Analyses" value="147" icon={FiActivity} color="blue" change="+12%" />
        <StatsCard title="Risk Assessments" value="89" icon={FiBarChart2} color="orange" change="+8%" />
        <StatsCard title="Literature Searches" value="234" icon={FiBookOpen} color="purple" change="+23%" />
        <StatsCard title="Chat Sessions" value="56" icon={FiMessageCircle} color="green" change="+15%" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Quick Actions</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Link to={feature.path}>
                  <div className="card hover:shadow-xl transition-all cursor-pointer">
                    <feature.icon className={`w-8 h-8 text-${feature.color}-500 mb-2`} />
                    <h3 className="font-semibold mb-1">{feature.title}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{feature.description}</p>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
        
        <RecentActivities />
      </div>
    </div>
  );
};

export default HomePage;