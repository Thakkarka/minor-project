import React, { useState } from 'react';
import { motion } from 'framer-motion';
import LiteratureSearch from '../components/Literature/LiteratureSearch';
import PubMedResults from '../components/Literature/PubMedResults';
import { literatureService } from '../services/literatureService';
import toast from 'react-hot-toast';

const LiteraturePage = () => {
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState([]);

  const handleSearch = async (query, filters) => {
    setLoading(true);
    try {
      const data = await literatureService.searchLiterature(query);
      setResults(data.results || []);
      toast.success(`Found ${data.results?.length || 0} articles`);
    } catch (error) {
      toast.error('Failed to search literature');
      setResults([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-2xl font-bold mb-4">Medical Literature Search</h1>
        <p className="text-gray-600 dark:text-gray-400 mb-6">
          Search through medical literature, clinical guidelines, and research articles
        </p>
        
        <LiteratureSearch onSearch={handleSearch} loading={loading} />
        
        <div className="mt-6">
          <PubMedResults results={results} loading={loading} />
        </div>
      </motion.div>
    </div>
  );
};

export default LiteraturePage;