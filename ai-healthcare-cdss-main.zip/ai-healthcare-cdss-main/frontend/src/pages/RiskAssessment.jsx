import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useApp } from '../context/AppContext';
import RiskScoreCard from '../components/Risk/RiskScoreCard';
import Input from '../components/Common/Input';
import Button from '../components/Common/Button';
import { riskService } from '../services/riskService';
import toast from 'react-hot-toast';

const RiskAssessment = () => {
  const { patientId } = useApp();
  const [loading, setLoading] = useState(false);
  const [riskData, setRiskData] = useState(null);
  const [formData, setFormData] = useState({
    age: '',
    bp_systolic: '',
    heart_rate: '',
    temperature: '',
    symptoms: '',
    medical_history: '',
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.age || !formData.symptoms) {
      toast.error('Please fill in required fields');
      return;
    }

    setLoading(true);
    try {
      const data = await riskService.calculateRisk({
        age: parseInt(formData.age),
        symptoms: formData.symptoms.split(',').map(s => s.trim()),
        vital_signs: {
          bp_systolic: formData.bp_systolic ? parseInt(formData.bp_systolic) : null,
          heart_rate: formData.heart_rate ? parseInt(formData.heart_rate) : null,
          temperature: formData.temperature ? parseFloat(formData.temperature) : null,
        },
        medical_history: formData.medical_history ? formData.medical_history.split(',').map(h => h.trim()) : [],
      });
      setRiskData(data);
      toast.success('Risk assessment completed');
    } catch (error) {
      toast.error('Failed to calculate risk');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-2xl font-bold mb-4">Risk Assessment</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="card">
            <h2 className="text-lg font-semibold mb-4">Patient Information</h2>
            <form onSubmit={handleSubmit}>
              <Input
                label="Age *"
                type="number"
                value={formData.age}
                onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                required
              />
              <Input
                label="Systolic BP (mmHg)"
                type="number"
                value={formData.bp_systolic}
                onChange={(e) => setFormData({ ...formData, bp_systolic: e.target.value })}
              />
              <Input
                label="Heart Rate (bpm)"
                type="number"
                value={formData.heart_rate}
                onChange={(e) => setFormData({ ...formData, heart_rate: e.target.value })}
              />
              <Input
                label="Temperature (°C)"
                type="number"
                step="0.1"
                value={formData.temperature}
                onChange={(e) => setFormData({ ...formData, temperature: e.target.value })}
              />
              <Input
                label="Symptoms * (comma-separated)"
                value={formData.symptoms}
                onChange={(e) => setFormData({ ...formData, symptoms: e.target.value })}
                placeholder="e.g., chest pain, shortness of breath"
                required
              />
              <Input
                label="Medical History (comma-separated)"
                value={formData.medical_history}
                onChange={(e) => setFormData({ ...formData, medical_history: e.target.value })}
                placeholder="e.g., hypertension, diabetes"
              />
              <Button type="submit" loading={loading} className="w-full">
                Calculate Risk
              </Button>
            </form>
          </div>

          {riskData && (
            <div>
              <RiskScoreCard riskData={riskData} />
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default RiskAssessment;