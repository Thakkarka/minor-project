import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useApp } from '../context/AppContext';
import SymptomInput from '../components/Symptoms/SymptomInput';
import SymptomForm from '../components/Symptoms/SymptomForm';
import BodyMap from '../components/Symptoms/BodyMap';
import { symptomService } from '../services/symptomService';
import toast from 'react-hot-toast';

const SymptomChecker = () => {
  const [activeTab, setActiveTab] = useState('text');
  const [loading, setLoading] = useState(false);
  const [selectedSymptoms, setSelectedSymptoms] = useState([]);
  const { setCurrentSymptoms, patientId } = useApp();
  const navigate = useNavigate();

  const handleTextSubmit = async (symptomsText) => {
    setLoading(true);
    try {
      const analysis = await symptomService.analyzeSymptoms({
        patient_id: patientId,
        symptoms: symptomsText,
      });
      setCurrentSymptoms(analysis);
      toast.success('Symptoms analyzed successfully!');
      navigate('/diagnosis');
    } catch (error) {
      toast.error('Failed to analyze symptoms');
    } finally {
      setLoading(false);
    }
  };

  const handleFormSubmit = async () => {
    if (selectedSymptoms.length === 0) {
      toast.error('Please select at least one symptom');
      return;
    }
    
    setLoading(true);
    try {
      const analysis = await symptomService.analyzeSymptoms({
        patient_id: patientId,
        symptoms: selectedSymptoms.join(', '),
      });
      setCurrentSymptoms(analysis);
      toast.success('Symptoms analyzed successfully!');
      navigate('/diagnosis');
    } catch (error) {
      toast.error('Failed to analyze symptoms');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex space-x-2 border-b dark:border-gray-700"
      >
        <button
          onClick={() => setActiveTab('text')}
          className={`px-4 py-2 font-medium transition-all ${
            activeTab === 'text'
              ? 'text-primary-600 border-b-2 border-primary-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Text Input
        </button>
        <button
          onClick={() => setActiveTab('form')}
          className={`px-4 py-2 font-medium transition-all ${
            activeTab === 'form'
              ? 'text-primary-600 border-b-2 border-primary-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Symptom Selector
        </button>
        <button
          onClick={() => setActiveTab('bodymap')}
          className={`px-4 py-2 font-medium transition-all ${
            activeTab === 'bodymap'
              ? 'text-primary-600 border-b-2 border-primary-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          Body Map
        </button>
      </motion.div>

      {activeTab === 'text' && (
        <SymptomInput onSubmit={handleTextSubmit} loading={loading} />
      )}

      {activeTab === 'form' && (
        <div className="space-y-4">
          <SymptomForm onSymptomsChange={setSelectedSymptoms} />
          <div className="flex justify-end">
            <button
              onClick={handleFormSubmit}
              disabled={loading || selectedSymptoms.length === 0}
              className="btn-primary"
            >
              {loading ? 'Analyzing...' : 'Analyze Symptoms'}
            </button>
          </div>
        </div>
      )}

      {activeTab === 'bodymap' && (
        <BodyMap onSelect={(symptoms) => setSelectedSymptoms(symptoms)} />
      )}
    </div>
  );
};

export default SymptomChecker;