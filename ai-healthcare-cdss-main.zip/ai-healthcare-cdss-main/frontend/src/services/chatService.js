import api from './api';

export const chatService = {
  sendMessage: async (data) => {
    return api.post('/api/chat/message', data);
  },
  
  clearSession: async (sessionId) => {
    return api.post(`/api/chat/clear/${sessionId}`);
  },
};