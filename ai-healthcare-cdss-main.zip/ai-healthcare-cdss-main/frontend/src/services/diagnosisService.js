import api from './api';

export const diagnosisService = {
  getDifferentialDiagnosis: async (data) => {
    return api.post('/api/diagnosis/differential', data);
  },
};