import api from './api';

export const feedbackService = {
  submitFeedback: async (data) => {
    return api.post('/api/feedback/submit', data);
  },
  
  getFeedbackForDiagnosis: async (diagnosisId) => {
    return api.get(`/api/feedback/diagnosis/${diagnosisId}`);
  },
};