import api from './api';

export const literatureService = {
  searchLiterature: async (query, topK = 5) => {
    return api.post('/api/literature/search', { query, top_k: topK });
  },
  
  getArticleDetails: async (articleId) => {
    return api.get(`/api/literature/article/${articleId}`);
  },
};