import api from './api';

export const riskService = {
  calculateRisk: async (data) => {
    return api.post('/api/risk/calculate', data);
  },
  
  interpretScore: async (score) => {
    return api.get(`/api/risk/interpret/${score}`);
  },
};