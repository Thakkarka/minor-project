import api from './api';

export const symptomService = {
  analyzeSymptoms: async (data) => {
    return api.post('/api/symptoms/analyze', data);
  },
  
  getSymptomHistory: async (patientId) => {
    return api.get(`/api/symptoms/history/${patientId}`);
  },
};