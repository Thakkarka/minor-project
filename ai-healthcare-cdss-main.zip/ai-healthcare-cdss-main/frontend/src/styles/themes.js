export const lightTheme = {
  background: '#ffffff',
  surface: '#f9fafb',
  text: '#111827',
  textSecondary: '#6b7280',
  border: '#e5e7eb',
  primary: '#4f46e5',
  secondary: '#8b5cf6',
  success: '#10b981',
  warning: '#f59e0b',
  error: '#ef4444',
};

export const darkTheme = {
  background: '#111827',
  surface: '#1f2937',
  text: '#f9fafb',
  textSecondary: '#9ca3af',
  border: '#374151',
  primary: '#6366f1',
  secondary: '#a78bfa',
  success: '#34d399',
  warning: '#fbbf24',
  error: '#f87171',
};

export const themes = {
  light: lightTheme,
  dark: darkTheme,
};