export const API_ENDPOINTS = {
  SYMPTOMS: '/api/symptoms',
  DIAGNOSIS: '/api/diagnosis',
  RISK: '/api/risk',
  LITERATURE: '/api/literature',
  CHAT: '/api/chat',
  FEEDBACK: '/api/feedback',
};

export const RISK_LEVELS = {
  LOW: { label: 'Low', color: 'green', min: 0, max: 20 },
  MODERATE: { label: 'Moderate', color: 'yellow', min: 20, max: 50 },
  HIGH: { label: 'High', color: 'orange', min: 50, max: 75 },
  CRITICAL: { label: 'Critical', color: 'red', min: 75, max: 100 },
};

export const SYMPTOM_CATEGORIES = [
  'General', 'Respiratory', 'Cardiovascular', 'Gastrointestinal',
  'Neurological', 'Musculoskeletal', 'Dermatological', 'Psychological'
];

export const APP_VERSION = process.env.REACT_APP_VERSION || '1.0.0';