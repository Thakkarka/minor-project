export const validateSymptoms = (symptoms) => {
  if (!symptoms || symptoms.trim().length === 0) {
    return 'Please enter symptoms';
  }
  if (symptoms.length > 5000) {
    return 'Symptoms text is too long (max 5000 characters)';
  }
  return null;
};

export const validateAge = (age) => {
  if (!age) return null;
  const numAge = parseInt(age);
  if (isNaN(numAge)) return 'Age must be a number';
  if (numAge < 0 || numAge > 150) return 'Age must be between 0 and 150';
  return null;
};

export const validateVitalSign = (value, min, max, name) => {
  if (!value) return null;
  const num = parseFloat(value);
  if (isNaN(num)) return `${name} must be a number`;
  if (num < min || num > max) return `${name} must be between ${min} and ${max}`;
  return null;
};