#!/bin/bash

# Cleanup Script - Remove generated files and reset environment

set -e

echo "🧹 Starting Cleanup..."

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Confirm cleanup
read -p "This will delete databases, caches, and node_modules. Are you sure? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]
then
    echo -e "${YELLOW}Cleanup cancelled${NC}"
    exit 1
fi

# Clean backend
echo -e "${YELLOW}Cleaning backend...${NC}"
cd backend
rm -rf venv
rm -rf __pycache__
rm -rf logs
rm -f sqlite.db
cd ..

# Clean frontend
echo -e "${YELLOW}Cleaning frontend...${NC}"
cd frontend
rm -rf node_modules
rm -rf build
rm -rf .cache
cd ..

# Clean database
echo -e "${YELLOW}Cleaning database...${NC}"
cd database
rm -f sqlite.db
rm -f *.db-journal
cd ..

# Clean Docker
echo -e "${YELLOW}Cleaning Docker...${NC}"
docker system prune -f

echo -e "${GREEN}✅ Cleanup completed!${NC}"
echo ""
echo "To setup again, run: ./scripts/setup.sh"