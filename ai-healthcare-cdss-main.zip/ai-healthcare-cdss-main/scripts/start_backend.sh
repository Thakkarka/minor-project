#!/bin/bash

# Start Backend Server

echo "🚀 Starting Backend Server..."

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Check if virtual environment exists
if [ ! -d "backend/venv" ]; then
    echo -e "${YELLOW}Virtual environment not found. Running setup first...${NC}"
    ./scripts/setup.sh
fi

# Activate virtual environment and start server
cd backend
source venv/bin/activate

# Check if .env exists
if [ ! -f ".env" ]; then
    echo -e "${YELLOW}⚠ .env file not found. Creating from example...${NC}"
    cp .env.example .env
    echo -e "${YELLOW}⚠ Please edit backend/.env and add your GEMINI_API_KEY${NC}"
    exit 1
fi

# Start the server
echo -e "${GREEN}Starting FastAPI server on http://localhost:8000${NC}"
echo -e "${GREEN}API Documentation: http://localhost:8000/docs${NC}"
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000