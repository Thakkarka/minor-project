#!/bin/bash

# Start Frontend Server

echo "🚀 Starting Frontend Server..."

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Check if node_modules exists
if [ ! -d "frontend/node_modules" ]; then
    echo -e "${YELLOW}Dependencies not installed. Running setup first...${NC}"
    ./scripts/setup.sh
fi

# Start the server
cd frontend
echo -e "${GREEN}Starting React development server on http://localhost:3000${NC}"
npm start